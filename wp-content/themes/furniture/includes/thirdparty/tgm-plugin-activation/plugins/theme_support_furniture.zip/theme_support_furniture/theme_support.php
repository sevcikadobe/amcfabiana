<?php
/*
Plugin Name: Theme Support Furniture
Plugin URI: http://themeforest.net/user/JollyThemes
Description: This plugin is compatible with all jollythemes wordpress themes. 
Author: Shahbaz Ahmed
Author URI: http://wow-themes.com
Version: 1.5.7
Text Domain: theme_support_furniture
*/
if( !defined( 'SH_TH_ROOT' ) ) define('SH_TH_ROOT', plugin_dir_path( __FILE__ ));
if( !defined( 'SH_TH_URL' ) ) define( 'SH_TH_URL', plugins_url( '', __FILE__ ) );
if( !defined( 'SH_NAME' ) ) define( 'SH_NAME', 'wp_furniture' );



function theme_support_furniture_plugin_load_textdomain() 
{
    load_plugin_textdomain( 'theme_support_furniture', FALSE, basename( dirname( __FILE__ ) ) . '/languages/' );
}

add_action( 'plugins_loaded', 'theme_support_furniture_plugin_load_textdomain' );

include_once( 'includes/loader.php' );


include_once( 'includes/loader.php' );