<?php
$options = array();
$options[] = array(
	'id'          => '_sh_seo_settings',
	'types'       => array('downloads'),
	'title'       => __('SEO Settings', 'theme_support_furniture'),
	'priority'    => 'low',
	'template'    => 
			array(
					
					array(
						'type' => 'toggle',
						'name' => 'seo_status',
						'label' => __('Enable SEO', 'theme_support_furniture'),
						'description' => __('Enable / disable seo settings for this post', 'theme_support_furniture'),
					),
					array(
						'type' => 'textbox',
						'name' => 'title',
						'label' => __('Meta Title', 'theme_support_furniture'),
						'description' => __('Enter meta title or leave it empty to use default title', 'theme_support_furniture'),
					),
					
					array(
						'type' => 'textarea',
						'name' => 'description',
						'label' => __('Meta Description', 'theme_support_furniture'),
						'default' => '',
						'description' => __('Enter meta description', 'theme_support_furniture'),
					),
					array(
						'type' => 'textarea',
						'name' => 'keywords',
						'label' => __('Meta Keywords', 'theme_support_furniture'),
						'default' => '',
						'description' => __('Enter meta keywords', 'theme_support_furniture'),
					),
				),
); /** SEO fields for custom posts and pages */
$options[] = array(
	'id'          => '_sh_layout_settings',
	'types'       => array('post', 'page', 'product', 'sh_services', ),
	'title'       => __('Layout Settings', 'theme_support_furniture'),
	'priority'    => 'high',
	'template'    => 
			array(
					
					array(
						'type' => 'radioimage',
						'name' => 'layout',
						'label' => __('Page Layout', 'theme_support_furniture'),
						'description' => __('Choose the layout for blog pages', 'theme_support_furniture'),
						'items' => array(
							array(
								'value' => 'left',
								'label' => __('Left Sidebar', 'theme_support_furniture'),
								'img' => SH_TH_URL.'/includes/vafpress/public/img/2cl.png',
							),
							array(
								'value' => 'right',
								'label' => __('Right Sidebar', 'theme_support_furniture'),
								'img' => SH_TH_URL.'/includes/vafpress/public/img/2cr.png',
							),
							array(
								'value' => 'full',
								'label' => __('Full Width', 'theme_support_furniture'),
								'img' => SH_TH_URL.'/includes/vafpress/public/img/1col.png',
							),
							
						),
					),
					
					array(
						'type' => 'select',
						'name' => 'sidebar',
						'label' => __('Sidebar', 'theme_support_furniture'),
						'default' => '',
						'items' => sh_get_sidebars(true)	
					),
				),
);
$options[] = array(
	'id'          => '_sh_header_settings',
	'types'       => array('post', 'page', 'product', 'sh_portfolio'),
	'title'       => __('Header Settings', 'theme_support_furniture'),
	'priority'    => 'high',
	'template'    => 
			array(
					
					
					array(
						'type' => 'upload',
						'name' => 'bg_image',
						'label' => __('Header Background Image', 'theme_support_furniture'),
						'description' => __('Choose the header background image', 'theme_support_furniture'),
					),
					array(
						'type' => 'textbox',
						'name' => 'header_title',
						'label' => __('Header Title', 'theme_support_furniture'),
						'description' => __('Enter header title', 'theme_support_furniture'),
					),
					array(
						'type' => 'notebox',
						'name' => 'nb_2',
						'label' => __('Info ', 'theme_support_furniture'),
						'description' => __('Below option will only work on pages and VC page template', 'theme_support_furniture'),
						'status' => 'info',
					),
					array(
						'type' => 'toggle',
						'name' => 'bread_crumb',
						'label' => __('Show/Hide breadcrumb on VC page', 'theme_support_furniture'),
						'description' => __('Only work with VC Page template', 'theme_support_furniture'),
					),
				),
);
$options[] =  array(
	'id'          => _WSH()->set_meta_key('post'),
	'types'       => array('post'),
	'title'       => __('Post Settings', 'theme_support_furniture'),
	'priority'    => 'high',
	'template'    => 
			array(		
					array(
						'type' => 'toggle',
						'name' => 'top_posts',
						'label' => __('Show/Hide top posts', 'theme_support_furniture'),
						'description' => __('Enable / disable seo Top post', 'theme_support_furniture'),
					),
					array(
							 'type'      => 'group',
							 'repeating' => true,
							 'length'    => 1,
							 'name'      => 'sh_gallery_imgs',
							 'title'     => __('Gallery images', 'theme_support_furniture'),
							 'fields'    => array(
								array(
							   'type' => 'upload',
							   'name' => 'gallery_image',
							   'label' => __('Gallery Image', 'theme_support_furniture'),
							   'description' => __('Choose the Gallery images', 'theme_support_furniture'),
							  ),
							 ),
							), 
					array(
						'type' => 'textarea',
						'name' => 'video',
						'label' => __('Video Embed Code', 'theme_support_furniture'),
						'default' => '',
						'description' => __('If post format is video then this embed code will be used in content', 'theme_support_furniture')
					),
					array(
						'type' => 'textarea',
						'name' => 'audio',
						'label' => __('Audio Embed Code', 'theme_support_furniture'),
						'default' => '',
						'description' => __('If post format is AUDIO then this embed code will be used in content', 'theme_support_furniture')
					),
					array(
						'type' => 'textarea',
						'name' => 'quote',
						'label' => __('Quote', 'theme_support_furniture'),
						'default' => '',
						'description' => __('If post format is quote then the content in this textarea will be displayed', 'theme_support_furniture')
					),
							
					
			),
);
/* Page options */
/** Team Options*/
$options[] =  array(
	'id'          => _WSH()->set_meta_key('sh_team'),
	'types'       => array('sh_team'),
	'title'       => __('Team Options', 'theme_support_furniture'),
	'priority'    => 'high',
	'template'    => array(
	
						
				array(
					'type' => 'textbox',
					'name' => 'designation',
					'label' => __('Designation', 'theme_support_furniture'),
					'default' => '',
				),
				array(
					'type'      => 'group',
					'repeating' => true,
					'length'    => 1,
					'name'      => 'sh_team_social',
					'title'     => __('Social Profile', 'theme_support_furniture'),
					'fields'    => array(
						
						array(
							'type' => 'fontawesome',
							'name' => 'social_icon',
							'label' => __('Social Icon', 'theme_support_furniture'),
							'default' => '',
						),
						
						array(
							'type' => 'textbox',
							'name' => 'social_link',
							'label' => __('Link', 'theme_support_furniture'),
							'default' => '',
							
						),
						
						
					),
				),
	),
);
/** Testimonial Options*/
$options[] =  array(
	'id'          => _WSH()->set_meta_key('sh_testimonials'),
	'types'       => array('sh_testimonials'),
	'title'       => __('Testimonials Options', 'theme_support_furniture'),
	'priority'    => 'high',
	'template'    => array(
				array(
					'type' => 'textbox',
					'name' => 'designation',
					'label' => __('Designation', 'theme_support_furniture'),
					'default' => 'happy customer',
				),
				array(
					'type' => 'select',
					'name' => 'testimonial_rating',
					'label' => __('Testimonial Rating', 'theme_support_furniture'),
					'description' => __('Choose the Testimonial Rating', 'theme_support_furniture'),
					'items' => array( 
						array(
								'value'=>'1',
								'label'=>'1'
							), 
						array(
								'value'=>'2',
								'label'=>'2'
							), 
						array(
								'value'=>'3',
								'label'=>'3'
							), 
						array(
								'value'=>'4',
								'label'=>'4'
							), 
						array(
								'value'=>'5',
								'label'=>'5'
							), 
						),
					'default' => '4'
				),
	),
);
/** Projects Options*/
$options[] =  array(
	'id'          => _WSH()->set_meta_key('sh_portfolio'),
	'types'       => array('sh_portfolio'),
	'title'       => __('Projects Options', 'theme_support_furniture'),
	'priority'    => 'high',
	'template'    => array(
				array(
					'type' => 'textbox',
					'name' => 'project_detail_title',
					'label' => __('Project Detail Section Title', 'theme_support_furniture'),
					'default' => '',
					'description' => __('Project Details', 'theme_support_furniture')
				),
				array(
					'type'      => 'group',
					'repeating' => true,
					'sortable'  => true,
					'name'      => 'extra_detail',
					'title'     => __('Extra Portfolio Details', 'theme_support_furniture'),
					'fields'    => array(
						array(
							'type'  => 'textbox',
							'name'  => 'label',
							'label' => __('Label', 'theme_support_furniture'),
						),
						array(
							'type'  => 'textbox',
							'name'  => 'value',
							'label' => __('Value', 'theme_support_furniture'),
						),
						
					),
				
				),
				array(
					'type'      => 'group',
					'repeating' => true,
					'sortable'  => true,
					'name'      => 'accordion',
					'title'     => __('Services Accordion', 'theme_support_furniture'),
					'fields'    => array(
						array(
							'type'  => 'textbox',
							'name'  => 'title',
							'label' => __('Title', 'theme_support_furniture'),
						),
						
						array(
							'type'                       => 'textarea',
							'label'                      => __('Content', 'theme_support_furniture'),
							'name'                       => 'content',
							'use_external_plugins'       => 1,
							'disabled_externals_plugins' => 'vp_sc_button',
							'disabled_internals_plugins' => '',
							'validation'                 => 'required',
						),
					),
				
				),
				array(
					'type'      => 'group',
					'repeating' => true,
					'sortable'  => true,
					'name'      => 'portfolio_images',
					'title'     => __('Portfolio Images', 'theme_support_furniture'),
					'fields'    => array(
						array(
							'type'  => 'upload',
							'name'  => 'image',
							'label' => __('Image', 'theme_support_furniture'),
						),
						
					),
				
				),
			    array(
					'type' => 'textarea',
					'name' => 'video',
					'label' => __('Video Embed Code', 'theme_support_furniture'),
					'default' => '',
					'description' => __('If Project Type is video then this embed code will be used in content', 'theme_support_furniture'),
				),
			    array(
					'type' => 'textarea',
					'name' => 'audio',
					'label' => __('Audio Embed Code', 'theme_support_furniture'),
					'default' => '',
					'description' => __('If Project Type is AUDIO then this embed code will be used in content', 'theme_support_furniture'),
				),
				
									
	),
);
$options[] =  array(
	'id'          => _WSH()->set_meta_key('product'),
	'types'       => array('product'),
	'title'       => __('Product Settings', 'theme_support_furniture'),
	'priority'    => 'high',
	'template'    => array(
		array(
			'type'      => 'group',
			'repeating' => true,
			'sortable'  => true,
			'name'      => 'product_color',
			'title'     => __('Product Color', 'theme_support_furniture'),
			'fields'    => array(
				array(
					'type'  => 'color',
					'name'  => 'product_color',
					'label' => __('Product Color', 'theme_support_furniture'),
				),
			),
		
		),
		array(
			'type'  => 'textbox',
			'name'  => 'manufacturer',
			'label' => __('Manufacturer', 'theme_support_furniture'),
		),
		array(
			'type'  => 'textbox',
			'name'  => 'availabilty',
			'label' => __('Availability', 'theme_support_furniture'),
		),
		array(
			'type'  => 'textbox',
			'name'  => 'product_code',
			'label' => __('Product Code', 'theme_support_furniture'),
		),
	),
);
 $options[] =  array(
	'id'          => _WSH()->set_meta_key('sh_catalog'),
	'types'       => array('sh_catalog'),
	'title'       => __('Catalog Settings', 'theme_support_furniture'),
	'priority'    => 'high',
	'template'    => array(
			array(
				'type' => 'upload',
				'name' => 'pdf',
				'label' => __('PDF file', 'theme_support_furniture'),
				'description' => __('Add PDF file', 'theme_support_furniture'),
				),
				
	),
);
$options[] =  array(
	'id'          => _WSH()->set_meta_key('sh_services'),
	'types'       => array( 'sh_services' ),
	'title'       => __('Services Settings', 'theme_support_furniture'),
	'priority'    => 'high',
	'template'    => 
			array(
				
				array(
					'type' => 'fontawesome',
					'name' => 'fontawesome',
					'label' => __('Service Icon', 'theme_support_furniture'),
					'default' => '',
				),
				array(
					'type' => 'upload',
					'name' => 'service_image',
					'label' => __('Services Image', 'theme_support_furniture'),
					'description' => __('Add Another image to services', 'theme_support_furniture'),
				),
			    array(
					'type' => 'textbox',
					'name' => 'readmore_text',
					'label' => __('Read More Text', 'theme_support_furniture'),
					'description' => __('Enter the Read more text', 'theme_support_furniture'),
					'default' => __('Read more', 'theme_support_furniture'),
				),
				array(
					'type' => 'textbox',
					'name' => 'readmore_link',
					'label' => __('Read More Button Link', 'theme_support_furniture'),
					'description' => __('Enter the Read more Link', 'theme_support_furniture'),
					'default' => __('#', 'theme_support_furniture'),
				),
				
				array(
					'type' => 'textbox',
					'name' => 'single_link',
					'label' => __('Read More Link', 'theme_support_furniture'),
					'description' => __('Enter the URL to redirect user for further reading', 'theme_support_furniture'),
				),
			),
);
/**
 * EOF
 */
 
 
 return $options;