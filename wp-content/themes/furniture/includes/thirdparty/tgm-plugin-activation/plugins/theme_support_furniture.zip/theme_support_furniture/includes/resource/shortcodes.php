<?php
$sh_sc = array();
$sh_sc['sh_services']	=	array(
					"name" => __("Services", 'theme_support_furniture'),
					"base" => "sh_services",
					"class" => "",
					"category" => __('Furniture', 'theme_support_furniture'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Service.', 'theme_support_furniture'),
					"params" => array(
						
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', 'theme_support_furniture' ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Services to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', 'theme_support_furniture' ),
						   "param_name" => "text_limit",
						   "description" => __('Enter text limit of Services to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', 'theme_support_furniture' ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)sh_get_categories( array( 'taxonomy' => 'services_category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", 'theme_support_furniture'),
						   "param_name" => "sort",
						   'value' => array_flip( array('date'=>__('Date', 'theme_support_furniture'),'title'=>__('Title', 'theme_support_furniture') ,'name'=>__('Name', 'theme_support_furniture') ,'author'=>__('Author', 'theme_support_furniture'),'comment_count' =>__('Comment Count', 'theme_support_furniture'),'random' =>__('Random', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", 'theme_support_furniture'),
						   "param_name" => "order",
						   'value' => array_flip(array('ASC'=>__('Ascending', 'theme_support_furniture'),'DESC'=>__('Descending', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
					)
				);
$sh_sc['sh_new_arrival'] = array(
			"name" => __("New Arrival", 'theme_support_furniture'),
			"base" => "sh_new_arrival",
			"class" => "",
			"category" => __('Furniture', 'theme_support_furniture'),
			"icon" => 'fa-user' ,
			'description' => __('show the New Arrival.', 'theme_support_furniture'),
			"params" => array(
			 	array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Title", 'theme_support_furniture'),
				   "param_name" => "title",
				   'value' => '',
				   "description" => __("Enter the Title", 'theme_support_furniture')
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Sub-Title", 'theme_support_furniture'),
				   "param_name" => "subtitle",
				   'value' => '',
				   "description" => __("Enter the Sub-Title", 'theme_support_furniture')
				),
				array(
				   "type" => "attach_image",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Background Image", 'theme_support_furniture'),
				   "param_name" => "img",
				   'value' => '',
				   "description" => __("Enter the Image url", 'theme_support_furniture')
				),
            				
			)
	    );

$sh_sc['sh_featured_products']	=	array(
					"name" => __("Featured Products", 'theme_support_furniture'),
					"base" => "sh_featured_products",
					"class" => "",
					"category" => __('Furniture', 'theme_support_furniture'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Products 4 column.', 'theme_support_furniture'),
					"params" => array(
						
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', 'theme_support_furniture' ),
						   "param_name" => "title",
						   "description" => __('Enter title to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Sub-Title', 'theme_support_furniture' ),
						   "param_name" => "subtitle",
						   "description" => __('Enter title to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', 'theme_support_furniture' ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Products to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', 'theme_support_furniture' ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)sh_get_categories( array( 'taxonomy' => 'product_cat', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", 'theme_support_furniture'),
						   "param_name" => "sort",
						   'value' => array_flip( array('date'=>__('Date', 'theme_support_furniture'),'title'=>__('Title', 'theme_support_furniture') ,'name'=>__('Name', 'theme_support_furniture') ,'author'=>__('Author', 'theme_support_furniture'),'comment_count' =>__('Comment Count', 'theme_support_furniture'),'random' =>__('Random', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", 'theme_support_furniture'),
						   "param_name" => "order",
						   'value' => array_flip(array('ASC'=>__('Ascending', 'theme_support_furniture'),'DESC'=>__('Descending', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
						array(
						   "type" => "checkbox",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Hide Overlay", 'theme_support_furniture'),
						   "param_name" => "hide_overlay",
						   'value' => array(__('Hide Overlay', 'theme_support_furniture')=>1),
						   "description" => __("Hide Overlay", 'theme_support_furniture')
						),
					)
				);

$sh_sc['sh_featured_cats']	=	array(
		"name" => __("Featured Categories", 'theme_support_furniture'),
		"base" => "sh_featured_cats",
		"class" => "",
		"category" => __('Furniture', 'theme_support_furniture'),
		"icon" => 'fa-briefcase' ,
		'description' => __('Show featured Categories.', 'theme_support_furniture'),
		"params" => array(
			array(
			   "type" => "textfield",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __('Enter  title', 'theme_support_furniture' ),
			   "param_name" => "title",
			   "description" => __('Enter title.', 'theme_support_furniture' )
			),
			array(
			   "type" => "textfield",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __('Enter sub-title', 'theme_support_furniture' ),
			   "param_name" => "subtitle",
			   "description" => __('Enter sub-title.', 'theme_support_furniture' )
			),
			array(
			   "type" => "textfield",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __('Number', 'theme_support_furniture' ),
			   "param_name" => "num",
			   "description" => __('Enter number of categories to show.', 'theme_support_furniture' )
			),
			array(
			   "type" => "dropdown",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __("Sort By", 'theme_support_furniture'),
			   "param_name" => "sort",
			   'value' => array(__('Name', 'theme_support_furniture')=>'name', __('Term ID', 'theme_support_furniture')=>'id', __('Slug', 'theme_support_furniture')=>'slug', __('Post Count', 'theme_support_furniture')=>'count',__('Term Group', 'theme_support_furniture')=>'term_group',),
			   "description" => __("Choose the sorting order.", 'theme_support_furniture')
			),
			array(
			   "type" => "dropdown",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __("Order", 'theme_support_furniture'),
			   "param_name" => "order",
			   'value' => array_flip(array('ASC'=>__('Ascending', 'theme_support_furniture'),'DESC'=>__('Descending', 'theme_support_furniture') ) ),			
			   "description" => __("Enter the sorting order.", 'theme_support_furniture')
			),
			array(
			   "type" => "checkbox",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __("Hide Empty Categories", 'theme_support_furniture'),
			   "param_name" => "empty",
			   'value' => array(__('Hide Empty cat', 'theme_support_furniture')=>1),
			   "description" => __("Hide Empty Categories", 'theme_support_furniture')
			),
			
			array(
			   "type" => "checkbox",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __("Hide Overlay", 'theme_support_furniture'),
			   "param_name" => "hide_overlay",
			   'value' => array(__('Hide Overlay', 'theme_support_furniture')=>1),
			   "description" => __("Hide Overlay", 'theme_support_furniture')
			     ),
			
			
		)
);

$sh_sc['sh_featured_products2']	=	array(
					"name" => __("Featured Products 2", 'theme_support_furniture'),
					"base" => "sh_featured_products2",
					"class" => "",
					"category" => __('Furniture', 'theme_support_furniture'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Products 3 column.', 'theme_support_furniture'),
					"params" => array(
						
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', 'theme_support_furniture' ),
						   "param_name" => "title",
						   "description" => __('Enter title to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Sub-Title', 'theme_support_furniture' ),
						   "param_name" => "subtitle",
						   "description" => __('Enter title to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', 'theme_support_furniture' ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Products to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', 'theme_support_furniture' ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)sh_get_categories( array( 'taxonomy' => 'product_cat', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", 'theme_support_furniture'),
						   "param_name" => "sort",
						   'value' => array_flip( array('date'=>__('Date', 'theme_support_furniture'),'title'=>__('Title', 'theme_support_furniture') ,'name'=>__('Name', 'theme_support_furniture') ,'author'=>__('Author', 'theme_support_furniture'),'comment_count' =>__('Comment Count', 'theme_support_furniture'),'random' =>__('Random', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", 'theme_support_furniture'),
						   "param_name" => "order",
						   'value' => array_flip(array('ASC'=>__('Ascending', 'theme_support_furniture'),'DESC'=>__('Descending', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
						array(
						   "type" => "checkbox",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Hide Overlay", 'theme_support_furniture'),
						   "param_name" => "hide_overlay",
						   'value' => array(__('Hide Overlay', 'theme_support_furniture')=>1),
						   "description" => __("Hide Overlay", 'theme_support_furniture')
						),
					)
				);

$sh_sc['sh_clients'] = array(
			"name" => __("Clients", 'theme_support_furniture'),
			"base" => "sh_clients",
			"class" => "",
			"category" => __('Furniture', 'theme_support_furniture'),
			"icon" => 'fa-user' ,
			'description' => __('show the Clients logo.', 'theme_support_furniture'),
			"params" => array(
			 	array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Title", 'theme_support_furniture'),
				   "param_name" => "title",
				   'value' => '',
				   "description" => __("Enter the Title", 'theme_support_furniture')
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Sub-Title", 'theme_support_furniture'),
				   "param_name" => "subtitle",
				   'value' => '',
				   "description" => __("Enter the Sub-Title", 'theme_support_furniture')
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Number", 'theme_support_furniture'),
				   "param_name" => "num",
				   'value' => '',
				   "description" => __("Enter the Number of Clients.", 'theme_support_furniture')
				),
				
            )
	    );

$sh_sc['sh_testimonial']	=	array(
		"name" => __("Testimonials", 'theme_support_furniture'),
		"base" => "sh_testimonial",
		"class" => "",
		"category" => __('Furniture', 'theme_support_furniture'),
		"icon" => 'fa-briefcase' ,
		'description' => __('Show testimonials.', 'theme_support_furniture'),
		"params" => array(
			array(
			   "type" => "textfield",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __('Title', 'theme_support_furniture' ),
			   "param_name" => "title",
			   "description" => __('Enter Title of testimonials to Show.', 'theme_support_furniture' )
			),
			array(
			   "type" => "textfield",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __('Sub-Title', 'theme_support_furniture' ),
			   "param_name" => "subtitle",
			   "description" => __('Enter Sub-Title of testimonials to Show.', 'theme_support_furniture' )
			),
			array(
			   "type" => "textfield",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __('Text Limit', 'theme_support_furniture' ),
			   "param_name" => "text_limit",
			   "description" => __('Enter text_limit of testimonials to Show.', 'theme_support_furniture' )
			),
			array(
			   "type" => "textfield",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __('Number', 'theme_support_furniture' ),
			   "param_name" => "num",
			   "description" => __('Enter Number of testimonials to Show.', 'theme_support_furniture' )
			),
		
			array(
			   "type" => "dropdown",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __( 'Category', 'theme_support_furniture' ),
			   "param_name" => "cat",
			   "value" => array_flip( (array)sh_get_categories( array( 'taxonomy' => 'testimonials_category', 'hide_empty' => FALSE ), true ) ),
			   "description" => __( 'Choose Category.', 'theme_support_furniture' )
			),
			array(
			   "type" => "dropdown",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __("Order By", 'theme_support_furniture'),
			   "param_name" => "sort",
			   'value' => array_flip( array('date'=>__('Date', 'theme_support_furniture'),'title'=>__('Title', 'theme_support_furniture') ,'name'=>__('Name', 'theme_support_furniture') ,'author'=>__('Author', 'theme_support_furniture'),'comment_count' =>__('Comment Count', 'theme_support_furniture'),'random' =>__('Random', 'theme_support_furniture') ) ),			
			   "description" => __("Enter the sorting order.", 'theme_support_furniture')
			),
			array(
			   "type" => "dropdown",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __("Order", 'theme_support_furniture'),
			   "param_name" => "order",
			   'value' => array_flip(array('ASC'=>__('Ascending', 'theme_support_furniture'),'DESC'=>__('Descending', 'theme_support_furniture') ) ),			
			   "description" => __("Enter the sorting order.", 'theme_support_furniture')
			),
		)
	);

$sh_sc['sh_services2']	=	array(
					"name" => __("Services 2", 'theme_support_furniture'),
					"base" => "sh_services2",
					"class" => "",
					"category" => __('Furniture', 'theme_support_furniture'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Service.', 'theme_support_furniture'),
					"params" => array(
						
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', 'theme_support_furniture' ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Services to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', 'theme_support_furniture' ),
						   "param_name" => "text_limit",
						   "description" => __('Enter text limit of Services to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', 'theme_support_furniture' ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)sh_get_categories( array( 'taxonomy' => 'services_category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", 'theme_support_furniture'),
						   "param_name" => "sort",
						   'value' => array_flip( array('date'=>__('Date', 'theme_support_furniture'),'title'=>__('Title', 'theme_support_furniture') ,'name'=>__('Name', 'theme_support_furniture') ,'author'=>__('Author', 'theme_support_furniture'),'comment_count' =>__('Comment Count', 'theme_support_furniture'),'random' =>__('Random', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", 'theme_support_furniture'),
						   "param_name" => "order",
						   'value' => array_flip(array('ASC'=>__('Ascending', 'theme_support_furniture'),'DESC'=>__('Descending', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
					)
				);

$sh_sc['sh_testimonial2']	=	array(
		"name" => __("Testimonials 2", 'theme_support_furniture'),
		"base" => "sh_testimonial2",
		"class" => "",
		"category" => __('Furniture', 'theme_support_furniture'),
		"icon" => 'fa-briefcase' ,
		'description' => __('Show testimonials.', 'theme_support_furniture'),
		"params" => array(
			array(
			   "type" => "textfield",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __('Title', 'theme_support_furniture' ),
			   "param_name" => "title",
			   "description" => __('Enter Title of testimonials to Show.', 'theme_support_furniture' )
			),
			array(
			   "type" => "textfield",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __('Sub-Title', 'theme_support_furniture' ),
			   "param_name" => "subtitle",
			   "description" => __('Enter Sub-Title of testimonials to Show.', 'theme_support_furniture' )
			),
			array(
			   "type" => "textfield",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __('Text Limit', 'theme_support_furniture' ),
			   "param_name" => "text_limit",
			   "description" => __('Enter text_limit of testimonials to Show.', 'theme_support_furniture' )
			),
			array(
			   "type" => "textfield",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __('Number', 'theme_support_furniture' ),
			   "param_name" => "num",
			   "description" => __('Enter Number of testimonials to Show.', 'theme_support_furniture' )
			),
		
			array(
			   "type" => "dropdown",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __( 'Category', 'theme_support_furniture' ),
			   "param_name" => "cat",
			   "value" => array_flip( (array)sh_get_categories( array( 'taxonomy' => 'testimonials_category', 'hide_empty' => FALSE ), true ) ),
			   "description" => __( 'Choose Category.', 'theme_support_furniture' )
			),
			array(
			   "type" => "dropdown",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __("Order By", 'theme_support_furniture'),
			   "param_name" => "sort",
			   'value' => array_flip( array('date'=>__('Date', 'theme_support_furniture'),'title'=>__('Title', 'theme_support_furniture') ,'name'=>__('Name', 'theme_support_furniture') ,'author'=>__('Author', 'theme_support_furniture'),'comment_count' =>__('Comment Count', 'theme_support_furniture'),'random' =>__('Random', 'theme_support_furniture') ) ),			
			   "description" => __("Enter the sorting order.", 'theme_support_furniture')
			),
			array(
			   "type" => "dropdown",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __("Order", 'theme_support_furniture'),
			   "param_name" => "order",
			   'value' => array_flip(array('ASC'=>__('Ascending', 'theme_support_furniture'),'DESC'=>__('Descending', 'theme_support_furniture') ) ),			
			   "description" => __("Enter the sorting order.", 'theme_support_furniture')
			),
		)
	);

$sh_sc['sh_blog']	=	array(
					"name" => __("Our Blog", 'theme_support_furniture'),
					"base" => "sh_blog",
					"class" => "",
					"category" => __('Furniture', 'theme_support_furniture'),
					"icon" => 'fa-briefcase',
					'description' => __('Show Blog Posts', 'theme_support_furniture'),
					"params" => array(
						
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', 'theme_support_furniture' ),
						   "param_name" => "title",
						   "description" => __('Enter Title of Posts to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Sub-Title', 'theme_support_furniture' ),
						   "param_name" => "subtitle",
						   "description" => __('Enter Sub-Title of Posts to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', 'theme_support_furniture' ),
						   "param_name" => "num",
						   "description" => __('Enter Number of posts to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', 'theme_support_furniture' ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)sh_get_categories( array( 'taxonomy' => 'category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", 'theme_support_furniture'),
						   "param_name" => "sort",
						   'value' => array_flip( array('date'=>__('Date', 'theme_support_furniture'),'title'=>__('Title', 'theme_support_furniture') ,'name'=>__('Name', 'theme_support_furniture') ,'author'=>__('Author', 'theme_support_furniture'),'comment_count' =>__('Comment Count', 'theme_support_furniture'),'random' =>__('Random', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", 'theme_support_furniture'),
						   "param_name" => "order",
						   'value' => array_flip(array('ASC'=>__('Ascending', 'theme_support_furniture'),'DESC'=>__('Descending', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
					)
				);

$sh_sc['sh_featured_products3']	=	array(
					"name" => __("Featured Products 3", 'theme_support_furniture'),
					"base" => "sh_featured_products3",
					"class" => "",
					"category" => __('Furniture', 'theme_support_furniture'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Products 1 column.', 'theme_support_furniture'),
					"params" => array(
						
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', 'theme_support_furniture' ),
						   "param_name" => "title",
						   "description" => __('Enter title to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', 'theme_support_furniture' ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Products to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', 'theme_support_furniture' ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)sh_get_categories( array( 'taxonomy' => 'product_cat', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", 'theme_support_furniture'),
						   "param_name" => "sort",
						   'value' => array_flip( array('date'=>__('Date', 'theme_support_furniture'),'title'=>__('Title', 'theme_support_furniture') ,'name'=>__('Name', 'theme_support_furniture') ,'author'=>__('Author', 'theme_support_furniture'),'comment_count' =>__('Comment Count', 'theme_support_furniture'),'random' =>__('Random', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", 'theme_support_furniture'),
						   "param_name" => "order",
						   'value' => array_flip(array('ASC'=>__('Ascending', 'theme_support_furniture'),'DESC'=>__('Descending', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
					)
				);

$sh_sc['sh_testimonial3']	=	array(
		"name" => __("Testimonials 3", 'theme_support_furniture'),
		"base" => "sh_testimonial3",
		"class" => "",
		"category" => __('Furniture', 'theme_support_furniture'),
		"icon" => 'fa-briefcase' ,
		'description' => __('Show testimonials.', 'theme_support_furniture'),
		"params" => array(
			array(
			   "type" => "textfield",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __('Title', 'theme_support_furniture' ),
			   "param_name" => "title",
			   "description" => __('Enter Title of testimonials to Show.', 'theme_support_furniture' )
			),
			array(
			   "type" => "textfield",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __('Text Limit', 'theme_support_furniture' ),
			   "param_name" => "text_limit",
			   "description" => __('Enter text_limit of testimonials to Show.', 'theme_support_furniture' )
			),
			array(
			   "type" => "textfield",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __('Number', 'theme_support_furniture' ),
			   "param_name" => "num",
			   "description" => __('Enter Number of testimonials to Show.', 'theme_support_furniture' )
			),
		
			array(
			   "type" => "dropdown",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __( 'Category', 'theme_support_furniture' ),
			   "param_name" => "cat",
			   "value" => array_flip( (array)sh_get_categories( array( 'taxonomy' => 'testimonials_category', 'hide_empty' => FALSE ), true ) ),
			   "description" => __( 'Choose Category.', 'theme_support_furniture' )
			),
			array(
			   "type" => "dropdown",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __("Order By", 'theme_support_furniture'),
			   "param_name" => "sort",
			   'value' => array_flip( array('date'=>__('Date', 'theme_support_furniture'),'title'=>__('Title', 'theme_support_furniture') ,'name'=>__('Name', 'theme_support_furniture') ,'author'=>__('Author', 'theme_support_furniture'),'comment_count' =>__('Comment Count', 'theme_support_furniture'),'random' =>__('Random', 'theme_support_furniture') ) ),			
			   "description" => __("Enter the sorting order.", 'theme_support_furniture')
			),
			array(
			   "type" => "dropdown",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __("Order", 'theme_support_furniture'),
			   "param_name" => "order",
			   'value' => array_flip(array('ASC'=>__('Ascending', 'theme_support_furniture'),'DESC'=>__('Descending', 'theme_support_furniture') ) ),			
			   "description" => __("Enter the sorting order.", 'theme_support_furniture')
			),
		)
	);

$sh_sc['sh_clients2'] = array(
			"name" => __("Clients 2", 'theme_support_furniture'),
			"base" => "sh_clients2",
			"class" => "",
			"category" => __('Furniture', 'theme_support_furniture'),
			"icon" => 'fa-user' ,
			'description' => __('show the Clients logo.', 'theme_support_furniture'),
			"params" => array(
			 	array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Title", 'theme_support_furniture'),
				   "param_name" => "title",
				   'value' => '',
				   "description" => __("Enter the Title", 'theme_support_furniture')
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Number", 'theme_support_furniture'),
				   "param_name" => "num",
				   'value' => '',
				   "description" => __("Enter the Number of Clients.", 'theme_support_furniture')
				),
				
            )
	    );

$sh_sc['sh_new_arrival2'] = array(
			"name" => __("New Arrival 2", 'theme_support_furniture'),
			"base" => "sh_new_arrival2",
			"class" => "",
			"category" => __('Furniture', 'theme_support_furniture'),
			"icon" => 'fa-user' ,
			'description' => __('show the New Arrival.', 'theme_support_furniture'),
			"params" => array(
			 	
				array(
				   "type" => "textarea",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Content", 'theme_support_furniture'),
				   "param_name" => "content",
				   'value' => '',
				   "description" => __("Enter the content", 'theme_support_furniture')
				),
				array(
				   "type" => "attach_image",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Background Image", 'theme_support_furniture'),
				   "param_name" => "img",
				   'value' => '',
				   "description" => __("Enter the Image url", 'theme_support_furniture')
				),
				array(
				   "type" => "dropdown",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Style", 'theme_support_furniture'),
				   "param_name" => "style",
				   'value' => array_flip(array('left'=>__('Left Style', 'theme_support_furniture'),'right'=>__('Right Style', 'theme_support_furniture') ) ),			
				   "description" => __("Enter the style", 'theme_support_furniture')
				),
            				
			)
	    );

$sh_sc['sh_new_products']	=	array(
					"name" => __("New Products", 'theme_support_furniture'),
					"base" => "sh_new_products",
					"class" => "",
					"category" => __('Furniture', 'theme_support_furniture'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Products 4 column.', 'theme_support_furniture'),
					"params" => array(
						
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', 'theme_support_furniture' ),
						   "param_name" => "title",
						   "description" => __('Enter title to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', 'theme_support_furniture' ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Products to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', 'theme_support_furniture' ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)sh_get_categories( array( 'taxonomy' => 'product_cat', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", 'theme_support_furniture'),
						   "param_name" => "sort",
						   'value' => array_flip( array('date'=>__('Date', 'theme_support_furniture'),'title'=>__('Title', 'theme_support_furniture') ,'name'=>__('Name', 'theme_support_furniture') ,'author'=>__('Author', 'theme_support_furniture'),'comment_count' =>__('Comment Count', 'theme_support_furniture'),'random' =>__('Random', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", 'theme_support_furniture'),
						   "param_name" => "order",
						   'value' => array_flip(array('ASC'=>__('Ascending', 'theme_support_furniture'),'DESC'=>__('Descending', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
					)
				);

$sh_sc['sh_featured_cats2']	=	array(
		"name" => __("Featured Categories 2", 'theme_support_furniture'),
		"base" => "sh_featured_cats2",
		"class" => "",
		"category" => __('Furniture', 'theme_support_furniture'),
		"icon" => 'fa-briefcase' ,
		'description' => __('Show featured Categories.', 'theme_support_furniture'),
		"params" => array(
			array(
			   "type" => "textfield",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __('Enter  title', 'theme_support_furniture' ),
			   "param_name" => "title",
			   "description" => __('Enter title.', 'theme_support_furniture' )
			),
			array(
			   "type" => "textfield",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __('Number', 'theme_support_furniture' ),
			   "param_name" => "num",
			   "description" => __('Enter number of categories to show.', 'theme_support_furniture' )
			),
			array(
			   "type" => "dropdown",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __("Sort By", 'theme_support_furniture'),
			   "param_name" => "sort",
			   'value' => array(__('Name', 'theme_support_furniture')=>'name', __('Term ID', 'theme_support_furniture')=>'id', __('Slug', 'theme_support_furniture')=>'slug', __('Post Count', 'theme_support_furniture')=>'count',__('Term Group', 'theme_support_furniture')=>'term_group',),
			   "description" => __("Choose the sorting order.", 'theme_support_furniture')
			),
			array(
			   "type" => "dropdown",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __("Order", 'theme_support_furniture'),
			   "param_name" => "order",
			   'value' => array_flip(array('ASC'=>__('Ascending', 'theme_support_furniture'),'DESC'=>__('Descending', 'theme_support_furniture') ) ),			
			   "description" => __("Enter the sorting order.", 'theme_support_furniture')
			),
			array(
			   "type" => "checkbox",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __("Hide Empty Categories", 'theme_support_furniture'),
			   "param_name" => "empty",
			   'value' => array(__('Hide Empty cat', 'theme_support_furniture')=>1),
			   "description" => __("Hide Empty Categories", 'theme_support_furniture')
			),
			
			
		)
);
$sh_sc['sh_product_tab']	=	array(
					"name" => __("Products Tabs", 'theme_support_furniture'),
					"base" => "sh_product_tab",
					"class" => "",
					"category" => __('Furniture', 'theme_support_furniture'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Products 3 column.', 'theme_support_furniture'),
					"params" => array(
						
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', 'theme_support_furniture' ),
						   "param_name" => "title",
						   "description" => __('Enter title to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', 'theme_support_furniture' ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Products to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', 'theme_support_furniture' ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)sh_get_categories( array( 'taxonomy' => 'product_cat', 'hide_empty' => FALSE ), false ) ),
						   "description" => __( 'Choose Category.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", 'theme_support_furniture'),
						   "param_name" => "sort",
						   'value' => array_flip( array('date'=>__('Date', 'theme_support_furniture'),'title'=>__('Title', 'theme_support_furniture') ,'name'=>__('Name', 'theme_support_furniture') ,'author'=>__('Author', 'theme_support_furniture'),'comment_count' =>__('Comment Count', 'theme_support_furniture'),'random' =>__('Random', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", 'theme_support_furniture'),
						   "param_name" => "order",
						   'value' => array_flip(array('ASC'=>__('Ascending', 'theme_support_furniture'),'DESC'=>__('Descending', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
					)
				);

$sh_sc['sh_testimonial4']	=	array(
		"name" => __("Testimonials 4", 'theme_support_furniture'),
		"base" => "sh_testimonial4",
		"class" => "",
		"category" => __('Furniture', 'theme_support_furniture'),
		"icon" => 'fa-briefcase' ,
		'description' => __('Show testimonials.', 'theme_support_furniture'),
		"params" => array(
			array(
			   "type" => "textfield",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __('Title', 'theme_support_furniture' ),
			   "param_name" => "title",
			   "description" => __('Enter Title of testimonials to Show.', 'theme_support_furniture' )
			),
			array(
			   "type" => "textfield",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __('Text Limit', 'theme_support_furniture' ),
			   "param_name" => "text_limit",
			   "description" => __('Enter text_limit of testimonials to Show.', 'theme_support_furniture' )
			),
			array(
			   "type" => "textfield",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __('Number', 'theme_support_furniture' ),
			   "param_name" => "num",
			   "description" => __('Enter Number of testimonials to Show.', 'theme_support_furniture' )
			),
		
			array(
			   "type" => "dropdown",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __( 'Category', 'theme_support_furniture' ),
			   "param_name" => "cat",
			   "value" => array_flip( (array)sh_get_categories( array( 'taxonomy' => 'testimonials_category', 'hide_empty' => FALSE ), true ) ),
			   "description" => __( 'Choose Category.', 'theme_support_furniture' )
			),
			array(
			   "type" => "dropdown",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __("Order By", 'theme_support_furniture'),
			   "param_name" => "sort",
			   'value' => array_flip( array('date'=>__('Date', 'theme_support_furniture'),'title'=>__('Title', 'theme_support_furniture') ,'name'=>__('Name', 'theme_support_furniture') ,'author'=>__('Author', 'theme_support_furniture'),'comment_count' =>__('Comment Count', 'theme_support_furniture'),'random' =>__('Random', 'theme_support_furniture') ) ),			
			   "description" => __("Enter the sorting order.", 'theme_support_furniture')
			),
			array(
			   "type" => "dropdown",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __("Order", 'theme_support_furniture'),
			   "param_name" => "order",
			   'value' => array_flip(array('ASC'=>__('Ascending', 'theme_support_furniture'),'DESC'=>__('Descending', 'theme_support_furniture') ) ),			
			   "description" => __("Enter the sorting order.", 'theme_support_furniture')
			),
		)
	);

$sh_sc['sh_featured_products4']	=	array(
					"name" => __("Featured Products 4", 'theme_support_furniture'),
					"base" => "sh_featured_products4",
					"class" => "",
					"category" => __('Furniture', 'theme_support_furniture'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Products 3 column.', 'theme_support_furniture'),
					"params" => array(
						
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', 'theme_support_furniture' ),
						   "param_name" => "title",
						   "description" => __('Enter title to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', 'theme_support_furniture' ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Products to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', 'theme_support_furniture' ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)sh_get_categories( array( 'taxonomy' => 'product_cat', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", 'theme_support_furniture'),
						   "param_name" => "sort",
						   'value' => array_flip( array('date'=>__('Date', 'theme_support_furniture'),'title'=>__('Title', 'theme_support_furniture') ,'name'=>__('Name', 'theme_support_furniture') ,'author'=>__('Author', 'theme_support_furniture'),'comment_count' =>__('Comment Count', 'theme_support_furniture'),'random' =>__('Random', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", 'theme_support_furniture'),
						   "param_name" => "order",
						   'value' => array_flip(array('ASC'=>__('Ascending', 'theme_support_furniture'),'DESC'=>__('Descending', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
						array(
						   "type" => "checkbox",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Hide Overlay", 'theme_support_furniture'),
						   "param_name" => "hide_overlay",
						   'value' => array(__('Hide Overlay', 'theme_support_furniture')=>1),
						   "description" => __("Hide Overlay", 'theme_support_furniture')
						),
					)
				);

$sh_sc['sh_services3']	=	array(
					"name" => __("Services 3", 'theme_support_furniture'),
					"base" => "sh_services3",
					"class" => "",
					"category" => __('Furniture', 'theme_support_furniture'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Service.', 'theme_support_furniture'),
					"params" => array(
						
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', 'theme_support_furniture' ),
						   "param_name" => "title",
						   "description" => __('Enter Title of Services section to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', 'theme_support_furniture' ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Services to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', 'theme_support_furniture' ),
						   "param_name" => "text_limit",
						   "description" => __('Enter text limit of Services to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', 'theme_support_furniture' ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)sh_get_categories( array( 'taxonomy' => 'services_category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", 'theme_support_furniture'),
						   "param_name" => "sort",
						   'value' => array_flip( array('date'=>__('Date', 'theme_support_furniture'),'title'=>__('Title', 'theme_support_furniture') ,'name'=>__('Name', 'theme_support_furniture') ,'author'=>__('Author', 'theme_support_furniture'),'comment_count' =>__('Comment Count', 'theme_support_furniture'),'random' =>__('Random', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", 'theme_support_furniture'),
						   "param_name" => "order",
						   'value' => array_flip(array('ASC'=>__('Ascending', 'theme_support_furniture'),'DESC'=>__('Descending', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
					)
				);
$sh_sc['sh_social_media'] = array(
			"name" => __("Social Media", 'theme_support_furniture'),
			"base" => "sh_social_media",
			"class" => "",
			"category" => __('Furniture', 'theme_support_furniture'),
			"icon" => 'fa-user' ,
			'description' => __('show the Social Profile links', 'theme_support_furniture'),
			"params" => array(
			 	array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Title", 'theme_support_furniture'),
				   "param_name" => "title",
				   'value' => '',
				   "description" => __("Enter the Title", 'theme_support_furniture')
				),
				array(
				   "type" => "textarea",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Content", 'theme_support_furniture'),
				   "param_name" => "content",
				   'value' => '',
				   "description" => __("Enter the text", 'theme_support_furniture')
				),
				array(
			   "type" => "checkbox",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __("Show social media", 'theme_support_furniture'),
			   "param_name" => "social_media",
			   'value' => array_flip(sh_social_media_array()),
			   "description" => __("Hide Empty Categories", 'theme_support_furniture')
			),
				           				
			)
	    );

$sh_sc['sh_catalog']	=	array(
					"name" => __("Catalog", 'theme_support_furniture'),
					"base" => "sh_catalog",
					"class" => "",
					"category" => __('Furniture', 'theme_support_furniture'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Catalog.', 'theme_support_furniture'),
					"params" => array(
						
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', 'theme_support_furniture' ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Services to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', 'theme_support_furniture' ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)sh_get_categories( array( 'taxonomy' => 'catalog_category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", 'theme_support_furniture'),
						   "param_name" => "sort",
						   'value' => array_flip( array('date'=>__('Date', 'theme_support_furniture'),'title'=>__('Title', 'theme_support_furniture') ,'name'=>__('Name', 'theme_support_furniture') ,'author'=>__('Author', 'theme_support_furniture'),'comment_count' =>__('Comment Count', 'theme_support_furniture'),'random' =>__('Random', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", 'theme_support_furniture'),
						   "param_name" => "order",
						   'value' => array_flip(array('ASC'=>__('Ascending', 'theme_support_furniture'),'DESC'=>__('Descending', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
						array(
						   "type" => "checkbox",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Hide Overlay", 'theme_support_furniture'),
						   "param_name" => "hide_overlay",
						   'value' => array(__('Hide Overlay', 'theme_support_furniture')=>1),
						   "description" => __("Hide Overlay", 'theme_support_furniture')
						 ),
					)
				);
$sh_sc['sh_google_map']	=	array(
					"name" => __("Google Map", 'theme_support_furniture'),
					"base" => "sh_google_map",
					"class" => "",
					"category" => __('Furniture', 'theme_support_furniture'),
					"icon" => 'fa-map-marker' ,
					'description' => __('Show the map Information', 'theme_support_furniture'),
					"params" => array(
						 array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Latitude', 'theme_support_furniture' ),
						   "param_name" => "lat",
						   "description" => __('Enter the Latitude', 'theme_support_furniture' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Longitude', 'theme_support_furniture' ),
						   "param_name" => "long",
						   "description" => __('Enter the Longitude', 'theme_support_furniture' )
						),
						 array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Marker Latitude', 'theme_support_furniture' ),
						   "param_name" => "mark_lat",
						   "description" => __('Enter the Latitude', 'theme_support_furniture' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Mark Longitude', 'theme_support_furniture' ),
						   "param_name" => "mark_long",
						   "description" => __('Enter the Longitude', 'theme_support_furniture' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Location Title', 'theme_support_furniture' ),
						   "param_name" => "location_title",
						   "description" => __('Enter the location title', 'theme_support_furniture' )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Location Address', 'theme_support_furniture' ),
						   "param_name" => "content",
						   "description" => __('Enter the Location address to show on marker', 'theme_support_furniture' )
						),
						array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Marker Image', 'theme_support_furniture' ),
						   "param_name" => "marker",
						   "description" => __('Choose the marker image or leave it to use default', 'theme_support_furniture' )
						),
						
					)
				);

$sh_sc['sh_contact_form']	=	array(
					"name" => __("Contact Form", 'theme_support_furniture'),
					"base" => "sh_contact_form",
					"class" => "",
					"category" => __('Furniture', 'theme_support_furniture'),
					"icon" => 'fa-envelope' ,
					'description' => __('Show the contact form', 'theme_support_furniture'),
					"params" => array(
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', 'theme_support_furniture' ),
						   "param_name" => "title",
						   "description" => __('Enter the title or leave empty for none.', 'theme_support_furniture' )
						),
						 array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Reciever Email Address', 'theme_support_furniture' ),
						   "param_name" => "email",
						   "description" => __('Enter the email id where email is recieve after form submission.', 'theme_support_furniture' )
						),
						
					)
				);
$sh_sc['sh_contact_facts']	=	array(
			"name" => __("Contact Facts", 'theme_support_furniture'),
			"base" => "sh_contact_facts",
			"class" => "",
			"category" => __('Furniture', 'theme_support_furniture'),
			"icon" => 'icon-wpb-layer-shape-text' ,
			"as_parent" => array('only' => 'sh_contact_fact'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
			"content_element" => true,
			"show_settings_on_create" => false,
			'description' => __('Add Contact Facts to your theme.', 'theme_support_furniture'),
			"params" => array(
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Title", 'theme_support_furniture'),
				   "param_name" => "title",
				   "description" => __("Enter the Title", 'theme_support_furniture')
				),
			
			),
			"js_view" => 'VcColumnView'
		);
$sh_sc['sh_contact_fact']	=	array(
			"name" => __("Contact Fact", 'theme_support_furniture'),
			"base" => "sh_contact_fact",
			"class" => "",
			"category" => __('Furniture', 'theme_support_furniture'),
			"icon" => 'icon-wpb-layer-shape-text' ,
			"as_child" => array('only' => 'sh_contact_facts'),// Use only|except attributes to limit child shortcodes (separate multiple values with comma)
			"content_element" => true,
			"show_settings_on_create" => true,
			'description' => __('Add Contact Fact.', 'theme_support_furniture'),
			"params" => array(
				array(
				   "type" => "dropdown",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __( 'FontAwesom icon', 'theme_support_furniture' ),
				   "param_name" => "icon",
				   "value" => (array)sh_get_fontawesome_icons(),
				   "description" => __( 'Choose Category.', 'theme_support_furniture' )
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Title", 'theme_support_furniture'),
				   "param_name" => "title",
				   "description" => __("Enter the Title to show.", 'theme_support_furniture')
				),
				array(
				   "type" => "textarea",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Text Content", 'theme_support_furniture'),
				   "param_name" => "content",
				   "description" => __("Enter the Text Content to show.", 'theme_support_furniture')
				),
				
				
							
			),
		);

$sh_sc['sh_team']	=	array(
					"name" => __("Team", 'theme_support_furniture'),
					"base" => "sh_team",
					"class" => "",
					"category" => __('Furniture', 'theme_support_furniture'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Teams.', 'theme_support_furniture'),
					"params" => array(
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', 'theme_support_furniture' ),
						   "param_name" => "title",
						   "description" => __('Enter the title or leave empty for none.', 'theme_support_furniture' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', 'theme_support_furniture' ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Services to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', 'theme_support_furniture' ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)sh_get_categories( array( 'taxonomy' => 'team_category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", 'theme_support_furniture'),
						   "param_name" => "sort",
						   'value' => array_flip( array('date'=>__('Date', 'theme_support_furniture'),'title'=>__('Title', 'theme_support_furniture') ,'name'=>__('Name', 'theme_support_furniture') ,'author'=>__('Author', 'theme_support_furniture'),'comment_count' =>__('Comment Count', 'theme_support_furniture'),'random' =>__('Random', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
						array(
						   "type" => "dropdown",
						   
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", 'theme_support_furniture'),
						   "param_name" => "order",
						   'value' => array_flip(array('ASC'=>__('Ascending', 'theme_support_furniture'),'DESC'=>__('Descending', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
					)
				);

$sh_sc['sh_call_to_action']	=	array(
					"name" => __("Call To Action", 'theme_support_furniture'),
					"base" => "sh_call_to_action",
					"class" => "",
					"category" => __('Furniture', 'theme_support_furniture'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Call to action.', 'theme_support_furniture'),
					"params" => array(
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', 'theme_support_furniture' ),
						   "param_name" => "title",
						   "description" => __('Enter the title or leave empty for none.', 'theme_support_furniture' )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', 'theme_support_furniture' ),
						   "param_name" => "text",
						   "description" => __('Enter Text to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Link', 'theme_support_furniture' ),
						   "param_name" => "btn_link",
						   "description" => __('Enter Button Link', 'theme_support_furniture' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Text', 'theme_support_furniture' ),
						   "param_name" => "btn_text",
						   "description" => __('Enter Button Text', 'theme_support_furniture' )
						),
						
					)
				);
$sh_sc['sh_pricing_section']	=	array(
			"name" => __("Pricing Section", 'theme_support_furniture'),
			"base" => "sh_pricing_section",
			"class" => "",
			"category" => __('Furniture', 'theme_support_furniture'),
			"icon" => 'icon-wpb-layer-shape-text' ,
			"as_parent" => array('only' => 'sh_pricing_table'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
			"content_element" => true,
			"show_settings_on_create" => false,
			'description' => __('Add Number of pricing tables to your theme.', 'theme_support_furniture'),
			"params" => array(
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Title", 'theme_support_furniture'),
				   "param_name" => "title",
				   "description" => __("Enter the title.", 'theme_support_furniture')
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("SubTitle", 'theme_support_furniture'),
				   "param_name" => "subtitle",
				   "description" => __("Enter the subtitle.", 'theme_support_furniture')
				),
			
			),
			"js_view" => 'VcColumnView'
		);
$sh_sc['sh_pricing_table']	=	array(
			"name" => __("Pricing Table", 'theme_support_furniture'),
			"base" => "sh_pricing_table",
			"class" => "",
			"category" => __('Furniture', 'theme_support_furniture'),
			"icon" => 'icon-wpb-layer-shape-text' ,
			"as_child" => array('only' => 'sh_pricing_section'),// Use only|except attributes to limit child shortcodes (separate multiple values with comma)
			"content_element" => true,
			"show_settings_on_create" => true,
			'description' => __('Add Pricing Table.', 'theme_support_furniture'),
			"params" => array(
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Title", 'theme_support_furniture'),
				   "param_name" => "title",
				   "description" => __("Enter the title to show.", 'theme_support_furniture')
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Price", 'theme_support_furniture'),
				   "param_name" => "price",
				   "description" => __("Enter the price to show", 'theme_support_furniture')
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Package Duration", 'theme_support_furniture'),
				   "param_name" => "package_duration",
				   "description" => __("Enter the Package duration to show", 'theme_support_furniture')
				),
				array(
				   "type" => "textarea",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Features", 'theme_support_furniture'),
				   "param_name" => "feature_str",
				   "description" => __("Enter the features to show one per line.", 'theme_support_furniture')
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Button Text", 'theme_support_furniture'),
				   "param_name" => "btn_text",
				   "description" => __("Enter the button text to show", 'theme_support_furniture')
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Button Link", 'theme_support_furniture'),
				   "param_name" => "btn_link",
				   "description" => __("Enter the button link to show", 'theme_support_furniture')
				),
				array(
				   "type" => "checkbox",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("is Active", 'theme_support_furniture'),
				   "param_name" => "active",
				   'value' => array(__('is active', 'theme_support_furniture')=>1),
				   "description" => __("is active or not", 'theme_support_furniture')
				),
			
			),
		);

$sh_sc['sh_services4']	=	array(
					"name" => __("Services 4", 'theme_support_furniture'),
					"base" => "sh_services4",
					"class" => "",
					"category" => __('Furniture', 'theme_support_furniture'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show services images', 'theme_support_furniture'),
					"params" => array(
						array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Large Image", 'theme_support_furniture'),
						   "param_name" => "img",
						   'value' => '',
						   "description" => __("Enter the Large Image", 'theme_support_furniture')
						),
						array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Small Image", 'theme_support_furniture'),
						   "param_name" => "img2",
						   'value' => '',
						   "description" => __("Enter the Small Image", 'theme_support_furniture')
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Link', 'theme_support_furniture' ),
						   "param_name" => "btn_link",
						   "description" => __('Enter Button Link', 'theme_support_furniture' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Text', 'theme_support_furniture' ),
						   "param_name" => "btn_text",
						   "description" => __('Enter Button Text', 'theme_support_furniture' )
						),
						
					)
				);
$sh_sc['sh_heading']	=	array(
					"name" => __("Heading", 'theme_support_furniture'),
					"base" => "sh_heading",
					"class" => "",
					"category" => __('Furniture', 'theme_support_furniture'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show the heading', 'theme_support_furniture'),
					"params" => array(
						
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', 'theme_support_furniture' ),
						   "param_name" => "title",
						   "description" => __('Enter the title', 'theme_support_furniture' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Sub-Title', 'theme_support_furniture' ),
						   "param_name" => "subtitle",
						   "description" => __('Enter the subtitle', 'theme_support_furniture' )
						),
						
					)
				);

$sh_sc['sh_services5']	=	array(
					"name" => __("Services 5", 'theme_support_furniture'),
					"base" => "sh_services5",
					"class" => "",
					"category" => __('Furniture', 'theme_support_furniture'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show services text', 'theme_support_furniture'),
					"params" => array(
						
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', 'theme_support_furniture' ),
						   "param_name" => "title",
						   "description" => __('Enter the title', 'theme_support_furniture' )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', 'theme_support_furniture' ),
						   "param_name" => "text",
						   "description" => __('Enter the Text', 'theme_support_furniture' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Read more text', 'theme_support_furniture' ),
						   "param_name" => "readmore_text",
						   "description" => __('Enter the Read more Text', 'theme_support_furniture' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Read more link', 'theme_support_furniture' ),
						   "param_name" => "readmore_link",
						   "description" => __('Enter the Read more Link', 'theme_support_furniture' )
						),
						
					)
				);

$sh_sc['sh_history']	=	array(
					"name" => __("History", 'theme_support_furniture'),
					"base" => "sh_history",
					"class" => "",
					"category" => __('Furniture', 'theme_support_furniture'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show History.', 'theme_support_furniture'),
					"params" => array(
						
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', 'theme_support_furniture' ),
						   "param_name" => "num",
						   "description" => __('Enter Number of post to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", 'theme_support_furniture'),
						   "param_name" => "sort",
						   'value' => array_flip( array('date'=>__('Date', 'theme_support_furniture'),'title'=>__('Title', 'theme_support_furniture') ,'name'=>__('Name', 'theme_support_furniture') ,'author'=>__('Author', 'theme_support_furniture'),'comment_count' =>__('Comment Count', 'theme_support_furniture'),'random' =>__('Random', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", 'theme_support_furniture'),
						   "param_name" => "order",
						   'value' => array_flip(array('ASC'=>__('Ascending', 'theme_support_furniture'),'DESC'=>__('Descending', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
					)
				);

$sh_sc['sh_services6']	=	array(
					"name" => __("Services 6", 'theme_support_furniture'),
					"base" => "sh_services6",
					"class" => "",
					"category" => __('Furniture', 'theme_support_furniture'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Service.', 'theme_support_furniture'),
					"params" => array(
						
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', 'theme_support_furniture' ),
						   "param_name" => "title",
						   "description" => __('Enter Title of Services to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', 'theme_support_furniture' ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Services to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', 'theme_support_furniture' ),
						   "param_name" => "text_limit",
						   "description" => __('Enter text limit of Services to Show.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', 'theme_support_furniture' ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)sh_get_categories( array( 'taxonomy' => 'services_category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", 'theme_support_furniture'),
						   "param_name" => "sort",
						   'value' => array_flip( array('date'=>__('Date', 'theme_support_furniture'),'title'=>__('Title', 'theme_support_furniture') ,'name'=>__('Name', 'theme_support_furniture') ,'author'=>__('Author', 'theme_support_furniture'),'comment_count' =>__('Comment Count', 'theme_support_furniture'),'random' =>__('Random', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", 'theme_support_furniture'),
						   "param_name" => "order",
						   'value' => array_flip(array('ASC'=>__('Ascending', 'theme_support_furniture'),'DESC'=>__('Descending', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
					)
				);
				
				

				
/*----------------------------------------------------------------------------------------------*/
$sh_sc['sh_projects']	=	array(
		"name" => __("Add Portfolio", 'theme_support_furniture'),
		"base" => "sh_projects",
		"class" => "",
		"category" => __('Furniture', 'theme_support_furniture'),
		"icon" => 'fa-briefcase' ,
		'description' => __('Show Posts from the portfolio.', 'theme_support_furniture'),
		"params" => array(
			array(
			   "type" => "textfield",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __('Enter  title', 'theme_support_furniture' ),
			   "param_name" => "title",
			   "description" => __('Enter portfolio title.', 'theme_support_furniture' )
			),
			array(
			   "type" => "textfield",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __('Number', 'theme_support_furniture' ),
			   "param_name" => "num",
			   "description" => __('Enter Number of Portfolio Posts to show.', 'theme_support_furniture' )
			),
			array(
			   "type" => "dropdown",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __( 'Category', 'theme_support_furniture' ),
			   "param_name" => "cat",
			   "value" => array_flip( (array)sh_get_categories( array( 'taxonomy' => 'portfolio_category', 'hide_empty' =>          FALSE ), true ) ),
			   "description" => __( 'Choose Category.', 'theme_support_furniture' )
			),
			array(
			   "type" => "dropdown",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __("Order By", 'theme_support_furniture'),
			   "param_name" => "sort",
			   'value' => array_flip( array('date'=>__('Date', 'theme_support_furniture'),'title'=>__('Title', 'theme_support_furniture') ,'name'=>__('Name', 'theme_support_furniture') ,'author'=>__('Author', 'theme_support_furniture'),'comment_count' =>__('Comment Count', 'theme_support_furniture'),'random' =>__('Random', 'theme_support_furniture') ) ),			
			   "description" => __("Enter the sorting order.", 'theme_support_furniture')
			),
			array(
			   "type" => "dropdown",
			   "holder" => "div",
			   "class" => "",
			   "heading" => __("Order", 'theme_support_furniture'),
			   "param_name" => "order",
			   'value' => array_flip(array('ASC'=>__('Ascending', 'theme_support_furniture'),'DESC'=>__('Descending', 'theme_support_furniture') ) ),			
			   "description" => __("Enter the sorting order.", 'theme_support_furniture')
			),
		)
	);
$sh_sc['sh_call_out'] = array(
			"name" => __("Call Out", 'theme_support_furniture'),
			"base" => "sh_call_out",
			"class" => "",
			"category" => __('Furniture', 'theme_support_furniture'),
			"icon" => 'fa-user' ,
			'description' => __('show the call out banner.', 'theme_support_furniture'),
			"params" => array(
			array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Enter Message on the banner", 'theme_support_furniture'),
				   "param_name" => "msg",
				   'value' => '',
				   "description" => __("Enter the message", 'theme_support_furniture')
				),
            array(
				   "type" => "dropdown",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __( 'Backgroud Color', 'theme_support_furniture' ),
				   "param_name" => "color",
				   "value" => array_flip(  array( 'true' => 'colorful', 'false' =>'None' ) ),
				   "description" => __( 'Choose background color left empty if you choosed the background image.', 'theme_support_furniture' )
				),				
			array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Button Text", 'theme_support_furniture'),
				   "param_name" => "btn_text",
				   'value' => '',
				   "description" => __("Enter the button text", 'theme_support_furniture')
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Button Link", 'theme_support_furniture'),
				   "param_name" => "btn_link",
				   'value' => '',
				   "description" => __("Enter the Image Link", 'theme_support_furniture')
				),
				array(
				   "type" => "attach_image",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Image", 'theme_support_furniture'),
				   "param_name" => "image",
				   'value' => '',
				   "description" => __("Enter the Image url", 'theme_support_furniture')
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Image Title", 'theme_support_furniture'),
				   "param_name" => "title",
				   'value' => '',
				   "description" => __("Enter the Image Title", 'theme_support_furniture')
				),		
			)
	    );
$sh_sc['sh_services_2']	=	array(
					"name" => __("Services 2", 'theme_support_furniture'),
					"base" => "sh_services_2",
					"class" => "",
					"category" => __('Furniture', 'theme_support_furniture'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Service.', 'theme_support_furniture'),
					"params" => array(
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', 'theme_support_furniture' ),
						   "param_name" => "title",
						   "description" => __('Enter the title or leave empty for none.', 'theme_support_furniture' )
						),
						  array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Inner Title', 'theme_support_furniture' ),
						   "param_name" => "title_inner",
						   "description" => __('Enter the Inner title or leave empty for none.', 'theme_support_furniture' )
						),
                        array(
				
							   "type" => "textfield",
				
							   "holder" => "div",
				
							   "class" => "",
				
							   "heading" => __('Enter text from title to make colorful', 'theme_support_furniture' ),
				
							   "param_name" => "title",
				
							   "description" => __('Enter the title text to make colorful make sure that text exists in title.', 'theme_support_furniture' )
				
							),
							
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', 'theme_support_furniture' ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Services to Show.', 'theme_support_furniture' )
						),
		
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', 'theme_support_furniture' ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)sh_get_categories( array( 'taxonomy' => 'services_category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", 'theme_support_furniture'),
						   "param_name" => "sort",
						   'value' => array_flip( array('date'=>__('Date', 'theme_support_furniture'),'title'=>__('Title', 'theme_support_furniture') ,'name'=>__('Name', 'theme_support_furniture') ,'author'=>__('Author', 'theme_support_furniture'),'comment_count' =>__('Comment Count', 'theme_support_furniture'),'random' =>__('Random', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
						array(
						   "type" => "dropdown",
						   
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", 'theme_support_furniture'),
						   "param_name" => "order",
						   'value' => array_flip(array('ASC'=>__('Ascending', 'theme_support_furniture'),'DESC'=>__('Descending', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
					)
				);
$sh_sc['sh_page_heading'] = array(
			"name" => __("Heading", 'theme_support_furniture'),
			"base" => "sh_page_heading",
			"class" => "",
			"category" => __('Furniture', 'theme_support_furniture'),
			"icon" => 'fa-user' ,
			'description' => __('show the heading.', 'theme_support_furniture'),
			"params" => array(
			array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Enter title", 'theme_support_furniture'),
				   "param_name" => "title",
				   'value' => '',
				   "description" => __("Enter the title", 'theme_support_furniture')
				),
			array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Enter inner titile", 'theme_support_furniture'),
				   "param_name" => "title_inner",
				   'value' => '',
				   "description" => __("Enter the inner title", 'theme_support_furniture')
				),
						
			)
	    );
$sh_sc['sh_services_list']	=	array(
					"name" => __("Services List", 'theme_support_furniture'),
					"base" => "sh_services_list",
					"class" => "",
					"category" => __('Furniture', 'theme_support_furniture'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Services List.', 'theme_support_furniture'),
					"params" => array(
								
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', 'theme_support_furniture' ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Services to Show.', 'theme_support_furniture' )
						),
		
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', 'theme_support_furniture' ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)sh_get_categories( array( 'taxonomy' => 'services_category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", 'theme_support_furniture'),
						   "param_name" => "sort",
						   'value' => array_flip( array('date'=>__('Date', 'theme_support_furniture'),'title'=>__('Title', 'theme_support_furniture') ,'name'=>__('Name', 'theme_support_furniture') ,'author'=>__('Author', 'theme_support_furniture'),'comment_count' =>__('Comment Count', 'theme_support_furniture'),'random' =>__('Random', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
						array(
						   "type" => "dropdown",
						   
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", 'theme_support_furniture'),
						   "param_name" => "order",
						   'value' => array_flip(array('ASC'=>__('Ascending', 'theme_support_furniture'),'DESC'=>__('Descending', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
					)
				);
$sh_sc['sh_about-slider'] = array(
			"name" => __("About-us Slider", 'theme_support_furniture'),
			"base" => "sh_about-slider",
			"class" => "",
			"category" => __('Furniture', 'theme_support_furniture'),
			"icon" => 'fa-user' ,
			'description' => __('Add images to the slider.', 'theme_support_furniture'),
			"params" => array(
	
				array(
				   "type" => "attach_images",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Image", 'theme_support_furniture'),
				   "param_name" => "image",
				   'value' => '',
				   "description" => __("Enter the Image url", 'theme_support_furniture')
				),
					
			)
	    );
$sh_sc['sh_accordion']	=	array(
					"name" => __("Blog Posts Accordion", 'theme_support_furniture'),
					"base" => "sh_accordion",
					"class" => "",
					"category" => __('Furniture', 'theme_support_furniture'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Accordion.', 'theme_support_furniture'),
					"params" => array(
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', 'theme_support_furniture' ),
						   "param_name" => "title",
						   "description" => __('Enter the title or leave empty for none.', 'theme_support_furniture' )
						),
						 
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', 'theme_support_furniture' ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Services to Show.', 'theme_support_furniture' )
						),
		
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', 'theme_support_furniture' ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)sh_get_categories( array( 'taxonomy' => 'services_category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', 'theme_support_furniture' )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", 'theme_support_furniture'),
						   "param_name" => "sort",
						   'value' => array_flip( array('date'=>__('Date', 'theme_support_furniture'),'title'=>__('Title', 'theme_support_furniture') ,'name'=>__('Name', 'theme_support_furniture') ,'author'=>__('Author', 'theme_support_furniture'),'comment_count' =>__('Comment Count', 'theme_support_furniture'),'random' =>__('Random', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
						array(
						   "type" => "dropdown",
						   
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", 'theme_support_furniture'),
						   "param_name" => "order",
						   'value' => array_flip(array('ASC'=>__('Ascending', 'theme_support_furniture'),'DESC'=>__('Descending', 'theme_support_furniture') ) ),			
						   "description" => __("Enter the sorting order.", 'theme_support_furniture')
						),
					)
				);
$sh_sc['sh_about']	=	array(
					"name" => __("About", 'theme_support_furniture'),
					"base" => "sh_about",
					"class" => "",
					"category" => __('Furniture', 'theme_support_furniture'),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show about the site.', 'theme_support_furniture'),
					"params" => array(
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', 'theme_support_furniture' ),
						   "param_name" => "title",
						   "description" => __('Enter the title or leave empty for none.', 'theme_support_furniture' )
						),
						  array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Inner Title', 'theme_support_furniture' ),
						   "param_name" => "title_inner",
						   "description" => __('Enter the Inner title or leave empty for none.', 'theme_support_furniture' )
						),
						array(
							   "type" => "attach_image",
							   "holder" => "div",
							   "class" => "",
							   "heading" => __("Image", 'theme_support_furniture'),
							   "param_name" => "image",
							   'value' => '',
							   "description" => __("Enter the Image url", 'theme_support_furniture')
							),
                       
					)
				);
		
$sh_sc['sh_contact_info']	=	array(
					"name" => __("Contact Information", 'theme_support_furniture'),
					"base" => "sh_contact_info",
					"class" => "",
					"category" => __('Furniture', 'theme_support_furniture'),
					"icon" => 'fa-envelope-o' ,
					'description' => __('Show the contact Information', 'theme_support_furniture'),
					"params" => array(
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', 'theme_support_furniture' ),
						   "param_name" => "title",
						   "description" => __('Enter the title or leave empty for none.', 'theme_support_furniture' )
						),
						 array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Address', 'theme_support_furniture' ),
						   "param_name" => "address",
						   "description" => __('Enter the address', 'theme_support_furniture' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Phone', 'theme_support_furniture' ),
						   "param_name" => "phone",
						   "description" => __('Enter the phone', 'theme_support_furniture' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Email', 'theme_support_furniture' ),
						   "param_name" => "email",
						   "description" => __('Enter the email', 'theme_support_furniture' )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Website URL', 'theme_support_furniture' ),
						   "param_name" => "website",
						   "description" => __('Enter the website url', 'theme_support_furniture' )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Office Hours', 'theme_support_furniture' ),
						   "param_name" => "content",
						   "description" => __('Enter the office working hours', 'theme_support_furniture' )
						),
					)
				);
/*----------------------------------------------------------------------------*/
$sh_sc = apply_filters( '_sh_shortcodes_array', $sh_sc );
	
return $sh_sc;