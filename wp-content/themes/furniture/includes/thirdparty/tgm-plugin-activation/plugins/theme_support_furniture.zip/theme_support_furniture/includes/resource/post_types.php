<?php

$theme_option = get_option(SH_NAME.'_theme_options') ; 

$team_slug = sh_set($theme_option , 'team_permalink' , 'team') ;

$services_slug = sh_set($theme_option , 'services_permalink' , 'services') ;

$testimonial_slug = sh_set($theme_option , 'testimonial_permalink' , 'testimonials') ;

$catalog_slug = sh_set($theme_option , 'catalog_permalink' , 'catalog') ;

$history_slug = sh_set($theme_option , 'history_permalink' , 'history') ;


//$faqs_slug = sh_set($theme_option , 'faqs_permalink' , 'faqs') ;

$options = array();

$options['sh_team'] = array(

								'labels' => array(__('Member', 'theme_support_furniture'), __('Member', 'theme_support_furniture')),

								'slug' => $team_slug ,

								'label_args' => array('menu_name' => __('Teams', 'theme_support_furniture')),

								'supports' => array( 'title', 'editor' , 'thumbnail'),

								'label' => __('Member', 'theme_support_furniture'),

								'args'=>array(

											'menu_icon'=>'dashicons-groups' , 

											'taxonomies'=>array('team_category')

								)

							);
$options['sh_services'] = array(

								'labels' => array(__('Service', 'theme_support_furniture'), __('Service', 'theme_support_furniture')),

								'slug' => $services_slug ,

								'label_args' => array('menu_name' => __('Services', 'theme_support_furniture')),

								'supports' => array( 'title' , 'editor' , 'thumbnail' ),

								'label' => __('Service', 'theme_support_furniture'),

								'args'=>array(

										'menu_icon'=>'dashicons-slides' , 

										'taxonomies'=>array('services_category')

								)

							);
$options['sh_testimonials'] = array(

								'labels' => array(__('Testimonial', 'theme_support_furniture'), __('Testimonial', 'theme_support_furniture')),

								'slug' => $testimonial_slug ,

								'label_args' => array('menu_name' => __('Testimonials', 'theme_support_furniture')),

								'supports' => array( 'title' , 'editor' , 'thumbnail' ),

								'label' => __('Testimonial', 'theme_support_furniture'),

								'args'=>array(

										'menu_icon'=>'dashicons-slides' , 

										'taxonomies'=>array('testimonial_category')

								)

							);							
																					


$options['sh_catalog'] = array(

								'labels' => array(__('Catalog', 'theme_support_furniture'), __('Catalog', 'theme_support_furniture')),

								'slug' => $catalog_slug ,

								'label_args' => array('menu_name' => __('Catalog', 'theme_support_furniture')),

								'supports' => array( 'title', 'editor' , 'thumbnail'),

								'label' => __('Catalog', 'theme_support_furniture'),

								'args'=>array(

											'menu_icon'=>'dashicons-slides' , 

											'taxonomies'=>array('catalog_category')

								)

							);

$options['sh_history'] = array(

								'labels' => array(__('History', 'theme_support_furniture'), __('History', 'theme_support_furniture')),

								'slug' => $history_slug ,

								'label_args' => array('menu_name' => __('History', 'theme_support_furniture')),

								'supports' => array( 'title', 'editor' , 'thumbnail'),

								'label' => __('History', 'theme_support_furniture'),

								'args'=>array(

											'menu_icon'=>'dashicons-slides' , 

											'taxonomies'=>array('history_category')

								)

							);														




/*$options['sh_faqs'] = array(

								'labels' => array(__('Faq', 'theme_support_furniture'), __('Faq', 'theme_support_furniture')),

								'slug' => $testimonial_slug ,

								'label_args' => array('menu_name' => __('Faq', 'theme_support_furniture')),

								'supports' => array( 'title' , 'editor' , 'thumbnail' ),

								'label' => __('Faq', 'theme_support_furniture'),

								'args'=>array(

										'menu_icon'=>'dashicons-slides' , 

										'taxonomies'=>array('faqs_category')

								)

							);*/	

