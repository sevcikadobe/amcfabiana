<?php
return array(
    'title' => __( 'Furniture House Theme Options', 'theme_support_furniture' ),
    'logo' => get_template_directory_uri() . '/images/logo.png',
    'menus' => array(
        // General Settings
         array(
             'title' => __( 'General Settings', 'theme_support_furniture' ),
            'name' => 'general_settings',
            'icon' => 'font-awesome:fa fa-cogs',
            'menus' => array(
                 
				array(
                    'title' => __( 'general Settings', 'theme_support_furniture' ),
                    'name' => 'general_sub_settings',
                    'icon' => 'font-awesome:fa fa-dashboard',
                    'controls' => array(
                        
                    	array(
                    		'type' => 'textbox',
                    		'name' => 'api_key',
                    		'label' => __( 'Map api key', SH_NAME ),
                    		'description' => __( 'Enter your api key', SH_NAME )
                    		),


						array(
                             'type' => 'section',
                            'repeating' => true,
                            'sortable' => true,
                            'title' => __( 'Purchase Information', 'theme_support_furniture' ),
                            'name' => 'purchase_information',
                            'description' => __( 'To get the auto theme updates provide purchase information', 'theme_support_furniture' ),
                            'fields' => array(
                                 
                                array(
                                    'type' => 'textbox',
                                    'name' => 'sh_purchase_code',
                                    'label' => __( 'Purchase Code', 'theme_support_furniture' ),
                                    'description' => __( 'To find the purchase code to TF downloads tab click on Download then choose "License and Purchase code"', 'theme_support_furniture' ),
                                    'default' => '',
                                ),
								array(
                                    'type' => 'textbox',
                                    'name' => 'sh_purchase_user',
                                    'label' => __( 'Themeforest Username', 'theme_support_furniture' ),
                                    'description' => __( 'Enter your themeforest username', 'theme_support_furniture' ),
                                    'default' => '',
                                ),
								
                                
                            ) 
                        ),
								array(
									'type' => 'toggle',
									'name' => 'hide_overlay',
									'label' => __( 'Hide Overlay', 'theme_support_furniture' ),
									'description' => __( 'Hide Overlay in woocommerce pages', 'theme_support_furniture' ),
									'default' => 0
								),
						
						 		array(
									'type' => 'color',
									'name' => 'custom_color_scheme',
									'label' => __( 'Green Color', 'theme_support_furniture' ),
									'description' => __( 'Choose the font color for green color', 'theme_support_furniture' ),
									'default' => '#3ab54a' 
								) 
						 
                    ) 
                    
                ),
				/** Submenu for heading settings */
                array(
                     'title' => __( 'Header Settings', 'theme_support_furniture' ),
                    'name' => 'header_settings',
                    'icon' => 'font-awesome:fa fa-dashboard',
                    'controls' => array(
                        array(
                             'type' => 'upload',
                            'name' => 'site_favicon',
                            'label' => __( 'Favicon', 'theme_support_furniture' ),
                            'description' => __( 'Upload the favicon, should be 16x16', 'theme_support_furniture' ),
                            'default' => '' 
                        ),
						array(
                            'type' => 'upload',
                            'name' => 'site_logo',
                            'label' => __( 'Logo', 'theme_support_furniture' ),
                            'description' => __( 'Upload the Logo, should be 159x25', 'theme_support_furniture' ),
                            'default' => '' 
                        ),
						array(
							'type' => 'select',
							'name' => 'header_style',
							'label' => __('Header Style', 'theme_support_furniture'),
							'description' => __('Choose the the Header Style', 'theme_support_furniture'),
							'items' => array( 
								array(
										'value'=>'1',
										'label'=>__( 'Header Style 1', 'theme_support_furniture' ),
									), 
								array(
										'value'=>'2',
										'label'=>__( 'Header Style 2', 'theme_support_furniture' ),
									), 
								),
							'default' => '1'
						),
						array(
							'type' => 'toggle',
							'name' => 'topbarstatus',
							'label' => __( 'Show Top Bar', 'theme_support_furniture' ),
							'description' => __( 'Show or hide top bar', 'theme_support_furniture' ),
							'default' => 0
						),
						array(
							'type' => 'section',
							
							'title' => __('Top bar settings', 'theme_support_furniture'),
							'name' => 'top_bar',
							'description' => __('This section is used for top bar area', 'theme_support_furniture'),
							'dependency' => array(
                                'field' => 'topbarstatus',
                                'function' => 'vp_dep_boolean' 
                            ),
							'fields' => array(
									array(
										'type' => 'toggle',
										'name' => 'topbar_left',
										'label' => __( 'Show Top Bar Left Menu', 'theme_support_furniture' ),
										'description' => __( 'Show Top Bar Left Menu', 'theme_support_furniture' ),
										'default' => 0
									),
									array(
										'type' => 'toggle',
										'name' => 'topbar_right',
										'label' => __( 'Show Top Bar Right Menu', 'theme_support_furniture' ),
										'description' => __( 'Show Top Bar Right Menu', 'theme_support_furniture' ),
										'default' => 0
									),
							),
						),
						array(
							'type' => 'toggle',
							'name' => 'searchbar',
							'label' => __( 'Show Header Search Section', 'theme_support_furniture' ),
							'description' => __( 'Show Header Search Section', 'theme_support_furniture' ),
							'default' => 0
						),
						array(
									'type' => 'select',
									'name' => 'wishlist_page',
									'label' => __('Wishlist Page', 'theme_support_furniture'),
									'description' => __('choose Wishlist page to show in header area, left it if you don\'t want to show wishlist link in header', 'theme_support_furniture'),
									'items' => array(
										'data' => array(
											array(
												'source' => 'function',
												'value' => 'vp_get_pages',
												),
											),
										)
									),
						array(
									'type' => 'select',
									'name' => 'compare_page',
									'label' => __('Compare Page', 'theme_support_furniture'),
									'description' => __('choose Compare page to show in header area, left it if you don\'t want to show Compare link in header', 'theme_support_furniture'),
									'items' => array(
										'data' => array(
											array(
												'source' => 'function',
												'value' => 'vp_get_pages',
												),
											),
										)
									),
						array(
									'type' => 'select',
									'name' => 'myaccount_page',
									'label' => __('My Account Page', 'theme_support_furniture'),
									'description' => __('choose My account page to show in header area, left it if you don\'t want to show wishlist link in header', 'theme_support_furniture'),
									'items' => array(
										'data' => array(
											array(
												'source' => 'function',
												'value' => 'vp_get_pages',
												),
											),
										)
									),						
						array(
									'type' => 'select',
									'name' => 'checkout_page',
									'label' => __('Checkout Page', 'theme_support_furniture'),
									'description' => __('choose Checkout page to show in header area, left it if you don\'t want to show wishlist link in header', 'theme_support_furniture'),
									'items' => array(
										'data' => array(
											array(
												'source' => 'function',
												'value' => 'vp_get_pages',
												),
											),
										)
									),
						array(
							'type' => 'toggle',
							'name' => 'shopping_cart_icon',
							'label' => __( 'Show/Hide Shopping cart icon', 'theme_support_furniture' ),
							'description' => __( 'Show/Hide Shopping cart icon', 'theme_support_furniture' ),
							'default' => 0
						),
						array(

								'type' => 'sorter',

								'name' => 'sorting_services',

								'max_selection' => 3,

								'label' => __('Choose services', 'theme_support_furniture'),

								'description' => __('Choose services to show in header', 'theme_support_furniture'),

								'items' => array(
									'data' => array(
										array(
											'source' => 'function',
											'value' => 'vp_get_services',
										),
									),
								),

							),
												
                       // Custom HEader Style End
                        array(
                             'type' => 'codeeditor',
                            'name' => 'header_css',
                            'label' => __( 'Header CSS', 'theme_support_furniture' ),
                            'description' => __( 'Write your custom css to include in header.', 'theme_support_furniture' ),
                            'theme' => 'github',
                            'mode' => 'css' 
                        ) 
                    ) 
                    
                ),
				/** Submenu for footer area */
                array(
                     'title' => __( 'Footer Settings', 'theme_support_furniture' ),
                    'name' => 'sub_footer_settings',
                    'icon' => 'font-awesome:fa fa-edit',
                    'controls' => array(
                        array(
							'type' => 'toggle',
							'name' => 'footer_top',
							'label' => __( 'Footer Top', 'theme_support_furniture' ),
							'description' => __( 'Enable or disable Footer Top', 'theme_support_furniture' ),
							'default' => 1 
						),
						array(
							'type' => 'toggle',
							'name' => 'footer_middle',
							'label' => __( 'Footer Middle', 'theme_support_furniture' ),
							'description' => __( 'Enable or disable Footer Middle', 'theme_support_furniture' ),
							'default' => 1 
						),
						array(
							'type' => 'toggle',
							'name' => 'footer_bottom',
							'label' => __( 'Footer Bottom', 'theme_support_furniture' ),
							'description' => __( 'Enable or disable Footer Bottom', 'theme_support_furniture' ),
							'default' => 1 
						),
						array(
                            'type' => 'upload',
                            'name' => 'footer_bg',
                            'label' => __( 'Footer Backgroun Image', 'theme_support_furniture' ),
                            'description' => __( 'Upload the Footer Background Image, should be 1605x563', 'theme_support_furniture' ),
                            'default' => '' 
                        ),
						array(
							'type' => 'textarea',
							'name' => 'copy_right',
							'label' => __( 'Copy Right Text', 'theme_support_furniture' ),
							'description' => __( 'Enter the Copy Right Text', 'theme_support_furniture' ),
							'default' => 'Ideas and designed BY JOLLythemes'
						),
                        array(
                             'type' => 'codeeditor',
                            'name' => 'footer_analytics',
                            'label' => __( 'Footer Analytics / Scripts', 'theme_support_furniture' ),
                            'description' => __( 'In this area you can put Google Analytics Code or any other Script that you want to be included in the footer before the Body tag.', 'theme_support_furniture' ),
                            'theme' => 'twilight',
                            'mode' => 'javascript' 
                        ) 
                        
                        
                        
                    ) 
                ), //End of submenu
				array(
                     'title' => __( 'Permalinks Settings', 'theme_support_furniture' ),
                    'name' => 'permalinks_settings',
                    'icon' => 'font-awesome:fa fa-link',
                    'controls' => array(
                         array(
                             'type' => 'section',
                            'name' => 'post_type_permalink_section',
                            'title' => 'Post Type Permalinks',
                            'fields' => array(
                                 array(
                                    'type' => 'textbox',
                                    'name' => 'team_permalink',
                                    'label' => __( 'Team Permalink', 'theme_support_furniture' ),
                                    'description' => __( 'Enter Slug for Team Post Type.', 'theme_support_furniture' ),
                                    'default' => '' 
                                ),
                                array(
                                    'type' => 'textbox',
                                    'name' => 'services_permalink',
                                    'label' => __( 'Services Permalink', 'theme_support_furniture' ),
                                    'description' => __( 'Enter Slug for Services Post Type.', 'theme_support_furniture' ),
                                    'default' => '' 
                                ),
                                array(
                                    'type' => 'textbox',
                                    'name' => 'testimonial_permalink',
                                    'label' => __( 'Testimonial Permalink', 'theme_support_furniture' ),
                                    'description' => __( 'Enter Permalink for Testimonial Post Type.', 'theme_support_furniture' ),
                                    'default' => '' 
                                ),
								array(
                                    'type' => 'textbox',
                                    'name' => 'catalog_permalink',
                                    'label' => __( 'Catalog Permalink', 'theme_support_furniture' ),
                                    'description' => __( 'Enter Permalink for Catalog Post Type.', 'theme_support_furniture' ),
                                    'default' => '' 
                                ),
								array(
                                    'type' => 'textbox',
                                    'name' => 'history_permalink',
                                    'label' => __( 'History Permalink', 'theme_support_furniture' ),
                                    'description' => __( 'Enter Permalink for History Post Type.', 'theme_support_furniture' ),
                                    'default' => '' 
                                ),
                                
								 
                            ) 
                        ),
                        array(
                             'type' => 'section',
                            'name' => 'category_permalink_section',
                            'title' => 'Category Permalinks',
                            'fields' => array(
                                 array(
                                    'type' => 'textbox',
                                    'name' => 'team_category_permalink',
                                    'label' => __( 'Team Category Permalink', 'theme_support_furniture' ),
                                    'description' => __( 'Enter Slug for Team Taxonomy.', 'theme_support_furniture' ),
                                    'default' => '' 
                                ),
                                
                                array(
                                    'type' => 'textbox',
                                    'name' => 'services_category_permalink',
                                    'label' => __( 'Services Category Permalink', 'theme_support_furniture' ),
                                    'description' => __( 'Enter Slug for Services Taxonomy.', 'theme_support_furniture' ),
                                    'default' => '' 
                                ),
                                array(
                                     'type' => 'textbox',
                                    'name' => 'testimonial_category_permalink',
                                    'label' => __( 'Testimonial Category Permalink', 'theme_support_furniture' ),
                                    'description' => __( 'Enter Permalink for Testimonial Taxonomy.', 'theme_support_furniture' ),
                                    'default' => '' 
                                ),
								array(
                                    'type' => 'textbox',
                                    'name' => 'catalog_category_permalink',
                                    'label' => __( 'Catalog Category Permalink', 'theme_support_furniture' ),
                                    'description' => __( 'Enter Permalink for Catalog Taxonomy.', 'theme_support_furniture' ),
                                    'default' => '' 
                                ),
								array(
                                    'type' => 'textbox',
                                    'name' => 'history_category_permalink',
                                    'label' => __( 'History Category Permalink', 'theme_support_furniture' ),
                                    'description' => __( 'Enter Permalink for History Taxonomy.', 'theme_support_furniture' ),
                                    'default' => '' 
                                ),
                                 
                            ) 
                        ) 
                    ) 
                ) //End of submenu
                
                
            ) 
        ),
        
		
		
		// Pages , Blog Pages Settings
        array(
             'title' => __( 'Page Settings', 'theme_support_furniture' ),
            'name' => 'general_settings',
            'icon' => 'font-awesome:fa fa-file',
            'menus' => array(
                
                // Search Page Settings 
                 array(
                     'title' => __( 'Search Page', 'theme_support_furniture' ),
                    'name' => 'search_page_settings',
                    'icon' => 'font-awesome:fa fa-search',
                    'controls' => array(
                        
						array(
                            'type' => 'textbox',
                            'name' => 'search_page_header_title',
                            'label' => __( 'Serch page Title', 'theme_support_furniture' ),
                            'description' => __( 'Enter the search page header title;', 'theme_support_furniture' ),
                            'default' => '',
							
                         ),
						 array(
                            'type' => 'upload',
                            'name' => 'search_page_header_img',
                            'label' => __( 'Header Image', 'theme_support_furniture' ),
                            'description' => __( 'choose the search page header image.', 'theme_support_furniture' ),
                            'default' => '',
							
                         ),
						array(
                             'type' => 'select',
                            'name' => 'search_page_sidebar',
                            'label' => __( 'Sidebar', 'theme_support_furniture' ),
                            'items' => array(
                                 'data' => array(
                                     array(
                                         'source' => 'function',
                                        'value' => 'sh_get_sidebars_2' 
                                    ) 
                                ) 
                            ),
                            'default' => array(
                                 '{{first}}' 
                            ) 
                        ),
                        array(
                             'type' => 'radioimage',
                            'name' => 'search_page_layout',
                            'label' => __( 'Page Layout', 'theme_support_furniture' ),
                            'description' => __( 'Choose the layout for blog pages', 'theme_support_furniture' ),
                            
                            'items' => array(
                                 array(
                                     'value' => 'left',
                                    'label' => __( 'Left Sidebar', 'theme_support_furniture' ),
                                    'img' => get_template_directory_uri() . '/includes/vafpress/public/img/2cl.png' 
                                ),
                                
                                array(
                                     'value' => 'right',
                                    'label' => __( 'Right Sidebar', 'theme_support_furniture' ),
                                    'img' => get_template_directory_uri() . '/includes/vafpress/public/img/2cr.png' 
                                ),
                                array(
                                     'value' => 'full',
                                    'label' => __( 'Full Width', 'theme_support_furniture' ),
                                    'img' => get_template_directory_uri() . '/includes/vafpress/public/img/1col.png' 
                                ) 
                                
                            ) 
                        ),
                    ) 
                ), // End of submenu
                
                // Archive Page Settings 
                array(
                     'title' => __( 'Archive Page', 'theme_support_furniture' ),
                    'name' => 'archive_page_settings',
                    'icon' => 'font-awesome:fa fa-archive',
                    'controls' => array(
                        array(
                            'type' => 'textbox',
                            'name' => 'archive_page_header_title',
                            'label' => __( 'Archive page Title', 'theme_support_furniture' ),
                            'description' => __( 'Enter the archive page header title;', 'theme_support_furniture' ),
                            'default' => '',
							
                         ),
						 array(
                            'type' => 'upload',
                            'name' => 'archive_page_header_img',
                            'label' => __( 'Header Image', 'theme_support_furniture' ),
                            'description' => __( 'choose the archive page header image.', 'theme_support_furniture' ),
                            'default' => '',
							
                         ),
						array(
                             'type' => 'select',
                            'name' => 'archive_page_sidebar',
                            'label' => __( 'Sidebar', 'theme_support_furniture' ),
                            'items' => array(
                                 'data' => array(
                                     array(
                                         'source' => 'function',
                                        'value' => 'sh_get_sidebars_2' 
                                    ) 
                                ) 
                            ),
                            'default' => array(
                                 '{{first}}' 
                            ) 
                        ),
                        array(
                             'type' => 'radioimage',
                            'name' => 'archive_page_layout',
                            'label' => __( 'Page Layout', 'theme_support_furniture' ),
                            'description' => __( 'Choose the layout for blog pages', 'theme_support_furniture' ),
                            
                            'items' => array(
                                 array(
                                     'value' => 'left',
                                    'label' => __( 'Left Sidebar', 'theme_support_furniture' ),
                                    'img' => get_template_directory_uri() . '/includes/vafpress/public/img/2cl.png' 
                                ),
                                
                                array(
                                     'value' => 'right',
                                    'label' => __( 'Right Sidebar', 'theme_support_furniture' ),
                                    'img' => get_template_directory_uri() . '/includes/vafpress/public/img/2cr.png' 
                                ),
                                array(
                                     'value' => 'full',
                                    'label' => __( 'Full Width', 'theme_support_furniture' ),
                                    'img' => get_template_directory_uri() . '/includes/vafpress/public/img/1col.png' 
                                ) 
                                
                            ) 
                        ) 
                        
                        
                    ) 
                ),
                
                // Author Page Settings 
                array(
                     'title' => __( 'Author Page', 'theme_support_furniture' ),
                    'name' => 'author_page_settings',
                    'icon' => 'font-awesome:fa fa-user',
                    'controls' => array(
                        
						array(
                            'type' => 'textbox',
                            'name' => 'author_page_header_title',
                            'label' => __( 'Author page Title', 'theme_support_furniture' ),
                            'description' => __( 'Enter the Author page header title;', 'theme_support_furniture' ),
                            'default' => '',
							
                         ),
						 array(
                            'type' => 'upload',
                            'name' => 'author_page_header_img',
                            'label' => __( 'Header Image', 'theme_support_furniture' ),
                            'description' => __( 'choose the author page header image.', 'theme_support_furniture' ),
                            'default' => '',
							
                         ),
						array(
                             'type' => 'select',
                            'name' => 'author_page_sidebar',
                            'label' => __( 'Sidebar', 'theme_support_furniture' ),
                            'items' => array(
                                 'data' => array(
                                     array(
                                         'source' => 'function',
                                        'value' => 'sh_get_sidebars_2' 
                                    ) 
                                ) 
                            ),
                            'default' => array(
                                 '{{first}}' 
                            ) 
                        ),
                        array(
                             'type' => 'radioimage',
                            'name' => 'author_page_layout',
                            'label' => __( 'Page Layout', 'theme_support_furniture' ),
                            'description' => __( 'Choose the layout for blog pages', 'theme_support_furniture' ),
                            
                            'items' => array(
                                 array(
                                     'value' => 'left',
                                    'label' => __( 'Left Sidebar', 'theme_support_furniture' ),
                                    'img' => get_template_directory_uri() . '/includes/vafpress/public/img/2cl.png' 
                                ),
                                
                                array(
                                     'value' => 'right',
                                    'label' => __( 'Right Sidebar', 'theme_support_furniture' ),
                                    'img' => get_template_directory_uri() . '/includes/vafpress/public/img/2cr.png' 
                                ),
                                array(
                                     'value' => 'full',
                                    'label' => __( 'Full Width', 'theme_support_furniture' ),
                                    'img' => get_template_directory_uri() . '/includes/vafpress/public/img/1col.png' 
                                ) 
                                
                            ) 
                        ) 
                        
                    ) 
                ),
                
            ) 
        ),
        
        // Sidebar Creator
        array(
             'title' => __( 'Sidebar Settings', 'theme_support_furniture' ),
            'name' => 'sidebar-settings',
            'icon' => 'font-awesome:fa fa-bars',
            'controls' => array(
                 array(
                     'type' => 'builder',
                    'repeating' => true,
                    'sortable' => true,
                    'label' => __( 'Dynamic Sidebar', 'theme_support_furniture' ),
                    'name' => 'dynamic_sidebar',
                    'description' => __( 'This section is used for theme color settings', 'theme_support_furniture' ),
                    'fields' => array(
                         array(
                             'type' => 'textbox',
                            'name' => 'sidebar_name',
                            'label' => __( 'Sidebar Name', 'theme_support_furniture' ),
                            'description' => __( 'Choose the default color scheme for the theme.', 'theme_support_furniture' ),
                            'default' => __( 'Dynamic Sidebar', 'theme_support_furniture' ) 
                        ) 
                    ) 
                ) 
            ) 
        ),
        
        // Dynamic Social Media Creator
        array(
             'title' => __( 'Social Media ', 'theme_support_furniture' ),
            'name' => 'social_media',
            'icon' => 'font-awesome:fa fa-share-square',
            'controls' => array(
                
				 array(
                     'type' => 'builder',
                    'repeating' => true,
                    'sortable' => true,
                    'label' => __( 'Social Media', 'theme_support_furniture' ),
                    'name' => 'social_media',
                    'description' => __( 'This section is used to add Social Media.', 'theme_support_furniture' ),
                    'fields' => array(
                         array(
                             'type' => 'textbox',
                            'name' => 'title',
                            'label' => __( 'Title', 'theme_support_furniture' ),
                            'description' => __( 'Enter the title of the social media.', 'theme_support_furniture' ), 
                        ),
						 array(
                             'type' => 'textbox',
                            'name' => 'social_link',
                            'label' => __( 'Link', 'theme_support_furniture' ),
                            'description' => __( 'Enter the Link for Social Media.', 'theme_support_furniture' ),
                            'default' => '#'
                        ),
                        array(
                            'type' => 'select',
                            'name' => 'social_icon',
                            'label' => __( 'Icon', 'theme_support_furniture' ),
                            'description' => __( 'Choose Icon for Social Media.', 'theme_support_furniture' ),
							'items' => array(
								'data' => array(
									array(
										'source' => 'function',
										'value' => 'vp_get_social_medias',
									),
								),
							),
                        )  
                    ) 
                ) 
            ) 
        ),
        
        
        /* Font settings */
        array(
             'title' => __( 'Font Settings', 'theme_support_furniture' ),
            'name' => 'font_settings',
            'icon' => 'font-awesome:fa fa-font',
            'menus' => array(
                /** heading font settings */
                 array(
                     'title' => __( 'Heading Font', 'theme_support_furniture' ),
                    'name' => 'heading_font_settings',
                    'icon' => 'font-awesome:fa fa-text-height',
                    
                    'controls' => array(
                        
                         array(
                             'type' => 'toggle',
                            'name' => 'use_custom_font',
                            'label' => __( 'Use Custom Font', 'theme_support_furniture' ),
                            'description' => __( 'Use custom font or not', 'theme_support_furniture' ),
                            'default' => 0 
                        ),
                        array(
                            'type' => 'section',
                            'title' => __( 'H1 Settings', 'theme_support_furniture' ),
                            'name' => 'h1_settings',
                            'description' => __( 'heading 1 font settings', 'theme_support_furniture' ),
                            'dependency' => array(
                                 'field' => 'use_custom_font',
                                'function' => 'vp_dep_boolean' 
                            ),
                            'fields' => array(
                                 array(
                                     'type' => 'select',
                                    'label' => __( 'Font Family', 'theme_support_furniture' ),
                                    'name' => 'h1_font_family',
                                    'description' => __( 'Select the font family to use for h1', 'theme_support_furniture' ),
                                    'items' => array(
                                         'data' => array(
                                             array(
                                                 'source' => 'function',
                                                'value' => 'vp_get_gwf_family' 
                                            ) 
                                        ) 
                                    ) 
                                    
                                ),
                                
                                array(
                                     'type' => 'color',
                                    'name' => 'h1_font_color',
                                    'label' => __( 'Font Color', 'theme_support_furniture' ),
                                    'description' => __( 'Choose the font color for heading h1', 'theme_support_furniture' ),
                                    'default' => '#98ed28' 
                                ) 
                            ) 
                        ),
                        array(
                             'type' => 'section',
                            'title' => __( 'H2 Settings', 'theme_support_furniture' ),
                            'name' => 'h2_settings',
                            'description' => __( 'heading h2 font settings', 'theme_support_furniture' ),
                            'dependency' => array(
                                 'field' => 'use_custom_font',
                                'function' => 'vp_dep_boolean' 
                            ),
                            'fields' => array(
                                 array(
                                     'type' => 'select',
                                    'label' => __( 'Font Family', 'theme_support_furniture' ),
                                    'name' => 'h2_font_family',
                                    'description' => __( 'Select the font family to use for h2', 'theme_support_furniture' ),
                                    'items' => array(
                                         'data' => array(
                                             array(
                                                 'source' => 'function',
                                                'value' => 'vp_get_gwf_family' 
                                            ) 
                                        ) 
                                    ) 
                                ),
                                array(
                                     'type' => 'color',
                                    'name' => 'h2_font_color',
                                    'label' => __( 'Font Color', 'theme_support_furniture' ),
                                    'description' => __( 'Choose the font color for heading h1', 'theme_support_furniture' ),
                                    'default' => '#98ed28' 
                                ) 
                            ) 
                        ),
                        array(
                             'type' => 'section',
                            'title' => __( 'H3 Settings', 'theme_support_furniture' ),
                            'name' => 'h3_settings',
                            'description' => __( 'heading h3 font settings', 'theme_support_furniture' ),
                            'dependency' => array(
                                 'field' => 'use_custom_font',
                                'function' => 'vp_dep_boolean' 
                            ),
                            'fields' => array(
                                
                                 array(
                                     'type' => 'select',
                                    'label' => __( 'Font Family', 'theme_support_furniture' ),
                                    'name' => 'h3_font_family',
                                    'description' => __( 'Select the font family to use for h3', 'theme_support_furniture' ),
                                    'items' => array(
                                         'data' => array(
                                             array(
                                                 'source' => 'function',
                                                'value' => 'vp_get_gwf_family' 
                                            ) 
                                        ) 
                                    ) 
                                    
                                ),
                                array(
                                     'type' => 'color',
                                    'name' => 'h3_font_color',
                                    'label' => __( 'Font Color', 'theme_support_furniture' ),
                                    'description' => __( 'Choose the font color for heading h3', 'theme_support_furniture' ),
                                    'default' => '#98ed28' 
                                ) 
                            ) 
                        ),
                        
                        array(
                             'type' => 'section',
                            'title' => __( 'H4 Settings', 'theme_support_furniture' ),
                            'name' => 'h4_settings',
                            'description' => __( 'heading h4 font settings', 'theme_support_furniture' ),
                            'dependency' => array(
                                 'field' => 'use_custom_font',
                                'function' => 'vp_dep_boolean' 
                            ),
                            'fields' => array(
                                
                                 array(
                                     'type' => 'select',
                                    'label' => __( 'Font Family', 'theme_support_furniture' ),
                                    'name' => 'h4_font_family',
                                    'description' => __( 'Select the font family to use for h4', 'theme_support_furniture' ),
                                    'items' => array(
                                         'data' => array(
                                             array(
                                                 'source' => 'function',
                                                'value' => 'vp_get_gwf_family' 
                                            ) 
                                        ) 
                                    ) 
                                    
                                ),
                                array(
                                     'type' => 'color',
                                    'name' => 'h4_font_color',
                                    'label' => __( 'Font Color', 'theme_support_furniture' ),
                                    'description' => __( 'Choose the font color for heading h4', 'theme_support_furniture' ),
                                    'default' => '#98ed28' 
                                ) 
                            ) 
                        ),
                        
                        array(
                             'type' => 'section',
                            'title' => __( 'H5 Settings', 'theme_support_furniture' ),
                            'name' => 'h5_settings',
                            'description' => __( 'heading h5 font settings', 'theme_support_furniture' ),
                            'dependency' => array(
                                 'field' => 'use_custom_font',
                                'function' => 'vp_dep_boolean' 
                            ),
                            'fields' => array(
                                
                                 array(
                                     'type' => 'select',
                                    'label' => __( 'Font Family', 'theme_support_furniture' ),
                                    'name' => 'h5_font_family',
                                    'description' => __( 'Select the font family to use for h5', 'theme_support_furniture' ),
                                    'items' => array(
                                         'data' => array(
                                             array(
                                                 'source' => 'function',
                                                'value' => 'vp_get_gwf_family' 
                                            ) 
                                        ) 
                                    ) 
                                    
                                ),
                                array(
                                     'type' => 'color',
                                    'name' => 'h5_font_color',
                                    'label' => __( 'Font Color', 'theme_support_furniture' ),
                                    'description' => __( 'Choose the font color for heading h5', 'theme_support_furniture' ),
                                    'default' => '#98ed28' 
                                ) 
                            ) 
                        ),
                        
                        array(
                             'type' => 'section',
                            'title' => __( 'H6 Settings', 'theme_support_furniture' ),
                            'name' => 'h6_settings',
                            'description' => __( 'heading h6 font settings', 'theme_support_furniture' ),
                            'dependency' => array(
                                 'field' => 'use_custom_font',
                                'function' => 'vp_dep_boolean' 
                            ),
                            'fields' => array(
                                
                                 array(
                                     'type' => 'select',
                                    'label' => __( 'Font Family', 'theme_support_furniture' ),
                                    'name' => 'h6_font_family',
                                    'description' => __( 'Select the font family to use for h6', 'theme_support_furniture' ),
                                    'items' => array(
                                         'data' => array(
                                             array(
                                                 'source' => 'function',
                                                'value' => 'vp_get_gwf_family' 
                                            ) 
                                        ) 
                                    ) 
                                    
                                ),
                                array(
                                     'type' => 'color',
                                    'name' => 'h6_font_color',
                                    'label' => __( 'Font Color', 'theme_support_furniture' ),
                                    'description' => __( 'Choose the font color for heading h6', 'theme_support_furniture' ),
                                    'default' => '#98ed28' 
                                ) 
                            ) 
                        ) 
                    ) 
                ),
                
                /** body font settings */
                array(
                     'title' => __( 'Body Font', 'theme_support_furniture' ),
                    'name' => 'body_font_settings',
                    'icon' => 'font-awesome:fa fa-text-width',
                    'controls' => array(
                         array(
                             'type' => 'toggle',
                            'name' => 'body_custom_font',
                            'label' => __( 'Use Custom Font', 'theme_support_furniture' ),
                            'description' => __( 'Use custom font or not', 'theme_support_furniture' ),
                            'default' => 0 
                        ),
                        array(
                             'type' => 'section',
                            'title' => __( 'Body Font Settings', 'theme_support_furniture' ),
                            'name' => 'body_font_settings1',
                            'description' => __( 'body font settings', 'theme_support_furniture' ),
                            'dependency' => array(
                                 'field' => 'body_custom_font',
                                'function' => 'vp_dep_boolean' 
                            ),
                            'fields' => array(
                                
                                 array(
                                     'type' => 'select',
                                    'label' => __( 'Font Family', 'theme_support_furniture' ),
                                    'name' => 'body_font_family',
                                    'description' => __( 'Select the font family to use for body', 'theme_support_furniture' ),
                                    'items' => array(
                                         'data' => array(
                                             array(
                                                 'source' => 'function',
                                                'value' => 'vp_get_gwf_family' 
                                            ) 
                                        ) 
                                    ) 
                                    
                                ),
                                
                                array(
                                     'type' => 'color',
                                    'name' => 'body_font_color',
                                    'label' => __( 'Font Color', 'theme_support_furniture' ),
                                    'description' => __( 'Choose the font color for heading body', 'theme_support_furniture' ),
                                    'default' => '#686868' 
                                ) 
                            ) 
                        ) 
                    ) 
                ) 
            ) 
        ), 
		 array(
             'title' => __( 'Clients', 'theme_support_furniture' ),
            'name' => 'brand_or_client',
            'icon' => 'font-awesome:fa fa-star',
            'controls' => array(
                 array(
                    'type' => 'builder',
                    'repeating' => true,
                    'sortable' => true,
                    'label' => __( 'Clients', 'theme_support_furniture' ),
                    'name' => 'brand_or_client',
                    'description' => __( 'Add as many clients as you want', 'theme_support_furniture' ),
                    'fields' => array(
						 
						 array(
							'type' => 'textbox',
							'name' => 'client_link',
							'label' => __( 'Client Link', 'theme_support_furniture' ),
							'description' => __( 'Enter the client Link', 'theme_support_furniture' ),
							'default' => ''
							 ),
						 array(
                           'type' => 'upload',
                            'name' => 'brand_img',
                            'label' => __( 'Logo', 'theme_support_furniture' ),
                            'description' => __( 'choose the client logo.', 'theme_support_furniture' ),
                            'default' => '' 
                         ),
						 
                    ) 
                ) 
            ) 
        ),
		
	) 
);
/**
 *EOF
 */